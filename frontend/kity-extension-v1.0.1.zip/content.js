"use strict";
(() => {
  // src/common/site-detect.ts
  function detectAdapterAlias(url) {
    const host = url.hostname;
    if (host.endsWith("chat.openai.com") || host === "chatgpt.com") {
      return "gpt";
    }
    if (host === "claude.ai" || host.endsWith(".claude.ai")) {
      return "claude";
    }
    if (host === "mail.google.com") {
      return "gmail";
    }
    if (host === "drive.google.com") {
      return "gdrive";
    }
    if (host.endsWith(".wikipedia.org")) {
      return "wpedia";
    }
    const amazonDomains = [
      ".amazon.com",
      ".amazon.co.uk",
      ".amazon.de",
      ".amazon.co.jp",
      ".amazon.ca",
      ".amazon.in",
      ".amazon.fr",
      ".amazon.it",
      ".amazon.es",
      ".amazon.com.au"
    ];
    if (amazonDomains.some((domain) => host.endsWith(domain))) {
      return "amazon";
    }
    if (host === "www.google.com" || host === "google.com" || host.endsWith(".google.com")) {
      return "google";
    }
    return "generic";
  }

  // src/common/dom.ts
  function showToast(message, duration = 2e3) {
    const existingToasts = document.querySelectorAll(".kity-toast");
    existingToasts.forEach((t) => t.remove());
    const toast = document.createElement("div");
    toast.className = "kity-toast";
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.classList.add("show"), 10);
    setTimeout(() => {
      toast.classList.remove("show");
      setTimeout(() => toast.remove(), 300);
    }, duration);
  }
  var messageCounterTimeout = null;
  function showMessageCounter(current, total, duration = 1500) {
    const existingCounter = document.querySelector(".kity-message-counter");
    if (existingCounter) {
      existingCounter.remove();
    }
    if (messageCounterTimeout !== null) {
      clearTimeout(messageCounterTimeout);
    }
    const counter = document.createElement("div");
    counter.className = "kity-message-counter";
    counter.textContent = `${current} of ${total} messages`;
    document.body.appendChild(counter);
    setTimeout(() => counter.classList.add("show"), 10);
    messageCounterTimeout = window.setTimeout(() => {
      counter.classList.remove("show");
      setTimeout(() => counter.remove(), 200);
      messageCounterTimeout = null;
    }, duration);
  }
  var focusRingTimeout = null;
  function setFocusRing(element) {
    if (!element || !element.isConnected) {
      console.warn("[Kity] Cannot set focus ring: element not in DOM");
      return;
    }
    if (focusRingTimeout !== null) {
      clearTimeout(focusRingTimeout);
      focusRingTimeout = null;
    }
    document.querySelectorAll(".kity-focus").forEach((el) => el.classList.remove("kity-focus"));
    element.classList.add("kity-focus");
    void element.getBoundingClientRect();
    console.log("[Kity] Focus ring set on:", element);
    element.scrollIntoView({ behavior: "instant", block: "center" });
    setTimeout(() => {
      if (element.classList.contains("kity-focus")) {
        element.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    }, 50);
    const tagName = element.tagName.toLowerCase();
    const isMain = tagName === "main";
    const isMessage = element.hasAttribute("data-message-author-role") || element.hasAttribute("data-message-id") || tagName === "article";
    if (isMain) {
      focusRingTimeout = window.setTimeout(() => {
        element.classList.remove("kity-focus");
        focusRingTimeout = null;
      }, 500);
    } else if (isMessage) {
      focusRingTimeout = window.setTimeout(() => {
        element.classList.remove("kity-focus");
        focusRingTimeout = null;
      }, 400);
    }
  }

  // src/content/adapters/chatgpt/selectors.ts
  var ChatGPTSelectors = class {
    /**
     * Get the sidebar navigation element
     */
    static getSidebar() {
      return document.querySelector('nav[aria-label="Chat history"]') || document.querySelector("nav.flex-col.flex-1") || document.querySelector("nav");
    }
    /**
     * Get the main content pane
     */
    static getMain() {
      return document.querySelector("main");
    }
    /**
     * Get the scroll container within main pane
     * Updated to support ChatGPT 5.2+ with multiple fallback strategies
     */
    static getScrollContainer() {
      const main = this.getMain();
      if (!main) return null;
      let container = document.querySelector('[data-scroll-root="true"]');
      if (container) {
        return container;
      }
      container = main.querySelector('[data-scroll-root="true"]');
      if (container) {
        return container;
      }
      container = main.querySelector(".overflow-y-auto");
      if (container) {
        return container;
      }
      const allElements = main.querySelectorAll("*");
      for (const candidate of allElements) {
        if (candidate.clientHeight < 100) {
          continue;
        }
        if (candidate.scrollHeight > candidate.clientHeight) {
          const oldScrollTop = candidate.scrollTop;
          candidate.scrollTop = oldScrollTop + 1;
          const canScroll = candidate.scrollTop !== oldScrollTop;
          candidate.scrollTop = oldScrollTop;
          if (canScroll) {
            return candidate;
          }
        }
      }
      const currentScrollY = window.scrollY || window.pageYOffset;
      const canScrollWindow = document.documentElement.scrollHeight > window.innerHeight;
      if (canScrollWindow) {
        window.scrollTo(0, currentScrollY + 1);
        const didScroll = window.scrollY !== currentScrollY;
        window.scrollTo(0, currentScrollY);
        if (didScroll) {
          return document.documentElement;
        }
      }
      return main;
    }
    /**
     * Get all user messages in the conversation
     */
    static getUserMessages() {
      const messages = Array.from(
        document.querySelectorAll('[data-message-author-role="user"]')
      );
      if (messages.length === 0) {
        const fallback = Array.from(
          document.querySelectorAll("[data-message-id]")
        ).filter((msg) => {
          const role = msg.getAttribute("data-message-author-role");
          return role === "user";
        });
        return fallback;
      }
      return messages;
    }
    /**
     * Get all messages (both user and assistant) in the main pane
     */
    static getAllMessages(excludeBottom = 0) {
      const main = this.getMain();
      const root = main ?? document;
      const messages = Array.from(root.querySelectorAll(this.MESSAGE_SELECTOR));
      if (excludeBottom > 0) {
        return messages.filter((msg) => {
          const rect = msg.getBoundingClientRect();
          return rect.bottom < window.innerHeight - excludeBottom && msg.textContent?.trim();
        });
      }
      return messages.filter((msg) => msg.textContent?.trim());
    }
    /**
     * Get all focusable elements in the sidebar
     */
    static getSidebarFocusableElements() {
      const sidebar = this.getSidebar();
      if (!sidebar) return [];
      const allElements = Array.from(
        sidebar.querySelectorAll('a, button, [role="button"], div')
      );
      return allElements.filter((el) => {
        const text = el.textContent?.trim();
        if (!text) return false;
        const isSimpleClickable = el.tagName === "A" || el.tagName === "BUTTON" || el.hasAttribute("role");
        const isSearchChatsInner = el.tagName === "DIV" && text.toLowerCase() === "search chats" && el.classList.toString().includes("grow");
        return isSimpleClickable || isSearchChatsInner;
      });
    }
    /**
     * Find the copy button near a code block
     */
    static findCopyButton(codeBlock) {
      const parent = codeBlock.parentElement;
      if (!parent) return null;
      const button = parent.querySelector('button[class*="copy"], button[aria-label*="Copy"]');
      return button;
    }
    /**
     * Check if element is inside the sidebar
     */
    static isInSidebar(element) {
      const sidebar = this.getSidebar();
      return !!(sidebar && sidebar.contains(element));
    }
    /**
     * Find parent message element for a given element
     */
    static findParentMessage(element) {
      let messageElement = element.closest(this.MESSAGE_SELECTOR);
      if (!messageElement) {
        let parent = element.parentElement;
        while (parent && parent !== document.body) {
          if (this.isMessageElement(parent)) {
            messageElement = parent;
            break;
          }
          parent = parent.parentElement;
        }
      }
      return messageElement;
    }
    /**
     * Check if element represents a ChatGPT message
     */
    static isMessageElement(element) {
      if (!element) {
        return false;
      }
      if (element.hasAttribute("data-message-author-role")) {
        return true;
      }
      if (element.hasAttribute("data-message-id")) {
        return true;
      }
      return element.tagName.toLowerCase() === "article";
    }
    /**
     * Find parent code block element for a given element
     */
    static findParentCodeBlock(element) {
      let codeBlock = element.closest("pre");
      if (!codeBlock) {
        let parent = element.parentElement;
        while (parent && parent !== document.body) {
          if (parent.tagName === "PRE") {
            codeBlock = parent;
            break;
          }
          parent = parent.parentElement;
        }
      }
      return codeBlock;
    }
  };
  ChatGPTSelectors.MESSAGE_SELECTOR = "[data-message-author-role], [data-message-id], article";

  // src/content/adapters/chatgpt/scroll-manager.ts
  var ScrollManager = class {
    constructor() {
      this.isScrolling = false;
      this.scrollDirection = null;
      this.scrollSpeed = 0;
      this.scrollAnimationId = null;
      this.maxScrollSpeed = 50;
      this.scrollAcceleration = 2;
      this.scrollDeceleration = 3;
    }
    /**
     * Start scrolling in the specified direction
     */
    startScroll(direction) {
      this.scrollDirection = direction;
      this.isScrolling = true;
      if (this.scrollAnimationId === null) {
        this.scrollSpeed = 0;
        this.runScrollAnimation();
      }
    }
    /**
     * Stop scrolling (with deceleration)
     */
    stopScroll() {
      this.isScrolling = false;
    }
    /**
     * Main scroll animation loop
     */
    runScrollAnimation() {
      const container = ChatGPTSelectors.getScrollContainer();
      if (!container) {
        console.log("[Kity] Scroll container not found");
        this.scrollAnimationId = null;
        return;
      }
      if (this.isScrolling) {
        this.scrollSpeed = Math.min(this.scrollSpeed + this.scrollAcceleration, this.maxScrollSpeed);
      } else {
        this.scrollSpeed = Math.max(this.scrollSpeed - this.scrollDeceleration, 0);
      }
      if (this.scrollSpeed > 0) {
        const delta = this.scrollDirection === "down" ? this.scrollSpeed : -this.scrollSpeed;
        if ("scrollBy" in container && typeof container.scrollBy === "function") {
          container.scrollBy(0, delta);
        } else {
          container.scrollTop += delta;
        }
      }
      if (this.scrollSpeed > 0) {
        this.scrollAnimationId = requestAnimationFrame(() => this.runScrollAnimation());
      } else {
        this.scrollAnimationId = null;
        this.scrollDirection = null;
      }
    }
  };

  // src/content/adapters/chatgpt/sidebar-navigator.ts
  var SidebarNavigator = class {
    /**
     * Focus the sidebar
     */
    focusSidebar() {
      const sidebar = ChatGPTSelectors.getSidebar();
      if (!sidebar) {
        showToast("No sidebar found");
        return;
      }
      const firstConversationLink = this.getFirstConversationLink(sidebar);
      const focusableElements = ChatGPTSelectors.getSidebarFocusableElements();
      const filtered = this.filterRedundantFolderElements(focusableElements);
      const firstConversation = firstConversationLink ?? filtered.find((el) => this.isConversationLink(el));
      if (firstConversation) {
        setFocusRing(firstConversation);
      } else if (filtered.length > 0) {
        setFocusRing(filtered[0]);
      } else {
        setFocusRing(sidebar);
      }
    }
    /**
     * Navigate up in the sidebar
     */
    navigateUp() {
      const focused = document.querySelector(".kity-focus");
      if (!focused) return;
      const prev = this.getPreviousFocusable(focused);
      if (!prev) return;
      setFocusRing(prev);
    }
    /**
     * Navigate down in the sidebar
     */
    navigateDown() {
      const focused = document.querySelector(".kity-focus");
      if (!focused) return;
      const next = this.getNextFocusable(focused);
      if (!next) return;
      setFocusRing(next);
    }
    isConversationLink(element) {
      if (element.tagName !== "A") {
        return false;
      }
      const href = element.getAttribute("href");
      return !!(href && href.includes("/c/"));
    }
    /**
     * Check if element is a folder element (not a conversation link)
     */
    isFolderElement(element) {
      const isButton = element.tagName === "BUTTON";
      const isLink = element.tagName === "A";
      if (!isButton && !isLink) {
        return false;
      }
      const text = element.textContent?.trim().toLowerCase();
      if (text === "chats" || text === "chat history") {
        return false;
      }
      if (isLink) {
        const href = element.getAttribute("href");
        if (href && href.includes("/c/")) {
          return false;
        }
      }
      return ChatGPTSelectors.isInSidebar(element);
    }
    /**
     * Filter out redundant folder elements (keep only every 3rd folder element)
     */
    filterRedundantFolderElements(elements) {
      const result = [];
      let i = 0;
      let inConversations = false;
      while (i < elements.length) {
        const el = elements[i];
        const text = el.textContent?.trim().toLowerCase();
        if (!inConversations && (text === "chats" || el.tagName === "A" && el.getAttribute("href")?.includes("/c/"))) {
          inConversations = true;
        }
        if (inConversations) {
          result.push(el);
          i++;
          continue;
        }
        if (this.isFolderElement(el)) {
          const next1 = elements[i + 1];
          const next2 = elements[i + 2];
          if (next1 && next2 && this.isFolderElement(next1) && this.isFolderElement(next2) && next1.textContent?.trim() === text && next2.textContent?.trim() === text) {
            result.push(next2);
            i += 3;
          } else {
            result.push(el);
            i++;
          }
        } else {
          result.push(el);
          i++;
        }
      }
      return result;
    }
    /**
     * Get the previous focusable element in the sidebar
     */
    getPreviousFocusable(element) {
      const allFocusable = ChatGPTSelectors.getSidebarFocusableElements();
      const filtered = this.filterRedundantFolderElements(allFocusable);
      const currentIndex = filtered.indexOf(element);
      if (currentIndex > 0) {
        return filtered[currentIndex - 1];
      }
      return null;
    }
    /**
     * Get the next focusable element in the sidebar
     */
    getNextFocusable(element) {
      const allFocusable = ChatGPTSelectors.getSidebarFocusableElements();
      const filtered = this.filterRedundantFolderElements(allFocusable);
      const currentIndex = filtered.indexOf(element);
      if (currentIndex >= 0 && currentIndex < filtered.length - 1) {
        return filtered[currentIndex + 1];
      }
      return null;
    }
    getFirstConversationLink(sidebar) {
      const links = Array.from(sidebar.querySelectorAll('a[href*="/c/"]'));
      if (links.length === 0) {
        return null;
      }
      const visible = links.find((link) => {
        const rect = link.getBoundingClientRect();
        const hasText = link.textContent?.trim();
        return !!hasText && rect.height > 0 && rect.width > 0;
      });
      return visible ?? links[0];
    }
  };

  // src/content/adapters/chatgpt/user-message-navigator.ts
  var UserMessageNavigator = class {
    constructor() {
      this.currentIndex = 0;
      this.userMessages = [];
      this.isInUserNavMode = false;
      this.lastNavType = null;
    }
    /**
     * Refresh the list of user messages
     */
    refreshUserMessages() {
      this.userMessages = ChatGPTSelectors.getUserMessages();
    }
    /**
     * Enter user navigation mode
     */
    enterUserNavMode() {
      this.isInUserNavMode = true;
      this.refreshUserMessages();
      if (this.userMessages.length === 0) {
        showToast("No user messages");
        return;
      }
      const currentFocus = document.querySelector(".kity-focus");
      if (currentFocus) {
        const focusedIndex = this.userMessages.indexOf(currentFocus);
        if (focusedIndex >= 0) {
          this.currentIndex = focusedIndex;
        } else {
          let closestIndex = 0;
          let minDistance = Infinity;
          const focusRect = currentFocus.getBoundingClientRect();
          this.userMessages.forEach((msg, idx) => {
            const msgRect = msg.getBoundingClientRect();
            const distance = Math.abs(msgRect.top - focusRect.top);
            if (distance < minDistance) {
              minDistance = distance;
              closestIndex = idx;
            }
          });
          this.currentIndex = closestIndex;
        }
      } else {
        this.currentIndex = this.userMessages.length - 1;
      }
      const targetMessage = this.userMessages[this.currentIndex];
      if (targetMessage && targetMessage.isConnected) {
        setFocusRing(targetMessage);
        showMessageCounter(this.currentIndex + 1, this.userMessages.length);
      } else {
        console.error("[Kity] Target message not found or not in DOM");
        showToast("Error: Cannot focus message");
      }
    }
    /**
     * Exit user navigation mode
     */
    exitUserNavMode() {
      this.isInUserNavMode = false;
    }
    /**
     * Navigate to previous user message
     */
    prevUser() {
      if (this.lastNavType === "general") {
        this.exitUserNavMode();
      }
      this.lastNavType = "user";
      if (!this.isInUserNavMode) {
        this.enterUserNavMode();
        return;
      }
      const currentFocus = document.querySelector(".kity-focus");
      this.refreshUserMessages();
      if (this.userMessages.length === 0) {
        showToast("No user messages");
        return;
      }
      if (currentFocus) {
        const newIndex = this.userMessages.findIndex((msg) => msg === currentFocus || msg.contains(currentFocus));
        if (newIndex !== -1) {
          this.currentIndex = newIndex;
          setFocusRing(this.userMessages[this.currentIndex]);
        }
      }
      if (this.currentIndex > 0) {
        this.currentIndex--;
        const targetMessage = this.userMessages[this.currentIndex];
        if (targetMessage && targetMessage.isConnected) {
          setFocusRing(targetMessage);
          showMessageCounter(this.currentIndex + 1, this.userMessages.length);
        } else {
          console.error("[Kity] Target message not found or not in DOM");
          showToast("Error: Cannot focus message");
        }
      }
    }
    /**
     * Navigate to next user message
     */
    nextUser() {
      if (this.lastNavType === "general") {
        this.exitUserNavMode();
      }
      this.lastNavType = "user";
      if (!this.isInUserNavMode) {
        this.enterUserNavMode();
        return;
      }
      const currentFocus = document.querySelector(".kity-focus");
      this.refreshUserMessages();
      if (this.userMessages.length === 0) {
        showToast("No user messages");
        return;
      }
      if (currentFocus) {
        const newIndex = this.userMessages.findIndex((msg) => msg === currentFocus || msg.contains(currentFocus));
        if (newIndex !== -1) {
          this.currentIndex = newIndex;
          setFocusRing(this.userMessages[this.currentIndex]);
        }
      }
      if (this.currentIndex < this.userMessages.length - 1) {
        this.currentIndex++;
        const targetMessage = this.userMessages[this.currentIndex];
        if (targetMessage && targetMessage.isConnected) {
          setFocusRing(targetMessage);
          showMessageCounter(this.currentIndex + 1, this.userMessages.length);
        } else {
          console.error("[Kity] Target message not found or not in DOM");
          showToast("Error: Cannot focus message");
        }
      }
    }
    /**
     * Mark navigation as switching to general mode
     */
    switchToGeneralNav() {
      this.lastNavType = "general";
    }
  };

  // src/content/adapters/chatgpt/text-selector.ts
  var TextSelector = class {
    constructor() {
      this.lastClickedMessage = null;
    }
    /**
     * Set the last clicked message
     */
    setLastClickedMessage(message) {
      this.lastClickedMessage = message;
    }
    /**
     * Select/deselect text in a message
     */
    selectText() {
      let targetMessage = null;
      if (this.lastClickedMessage && document.body.contains(this.lastClickedMessage)) {
        targetMessage = this.lastClickedMessage;
      } else {
        const main = ChatGPTSelectors.getMain();
        if (!main) {
          showToast("No main pane found");
          return;
        }
        const allMessages = main.querySelectorAll("[data-message-author-role]");
        const messages = Array.from(allMessages).filter((msg) => {
          const rect = msg.getBoundingClientRect();
          const windowHeight = window.innerHeight;
          const isVisible = rect.top < windowHeight && rect.bottom > 0;
          const hasContent = msg.textContent && msg.textContent.trim().length > 0;
          return isVisible && hasContent;
        });
        if (messages.length === 0) {
          showToast("No messages found");
          return;
        }
        const viewportCenter = window.innerHeight / 2;
        let minDistance = Infinity;
        for (const msg of messages) {
          const rect = msg.getBoundingClientRect();
          const msgCenter = rect.top + rect.height / 2;
          const distance = Math.abs(msgCenter - viewportCenter);
          if (rect.top < window.innerHeight && rect.bottom > 0) {
            if (distance < minDistance) {
              minDistance = distance;
              targetMessage = msg;
            }
          }
        }
        if (!targetMessage) {
          showToast("No visible message");
          return;
        }
      }
      if (targetMessage.classList.contains("kity-selected")) {
        targetMessage.classList.remove("kity-selected");
        showToast("Text deselected");
      } else {
        document.querySelectorAll(".kity-selected").forEach((el) => el.classList.remove("kity-selected"));
        targetMessage.classList.add("kity-selected");
      }
    }
    /**
     * Extend text selection up (line-based)
     */
    extendSelectionUp() {
      const sel = window.getSelection();
      if (!sel || sel.rangeCount === 0) return;
      const range = sel.getRangeAt(0);
      const container = range.commonAncestorContainer;
      const parent = container.parentElement;
      if (!parent) return;
      const prev = this.getPreviousTextSibling(container);
      if (prev) {
        range.setStartBefore(prev);
        sel.removeAllRanges();
        sel.addRange(range);
      }
    }
    /**
     * Extend text selection down (line-based)
     */
    extendSelectionDown() {
      const sel = window.getSelection();
      if (!sel || sel.rangeCount === 0) return;
      const range = sel.getRangeAt(0);
      const container = range.commonAncestorContainer;
      const next = this.getNextTextSibling(container);
      if (next) {
        range.setEndAfter(next);
        sel.removeAllRanges();
        sel.addRange(range);
      }
    }
    /**
     * Get previous text sibling node
     */
    getPreviousTextSibling(node) {
      let prev = node.previousSibling;
      while (prev && prev.nodeType !== Node.TEXT_NODE) {
        prev = prev.previousSibling;
      }
      return prev;
    }
    /**
     * Get next text sibling node
     */
    getNextTextSibling(node) {
      let next = node.nextSibling;
      while (next && next.nodeType !== Node.TEXT_NODE) {
        next = next.nextSibling;
      }
      return next;
    }
  };

  // src/content/adapters/chatgpt/code-copier.ts
  var CodeCopier = class {
    constructor() {
      this.mouseX = 0;
      this.mouseY = 0;
      this.hasMouseMoved = false;
      // Track if mouse has moved at least once
      this.DISTANCE_THRESHOLD = 150;
      // pixels
      this.MIN_HIGHLIGHT_DURATION = 200;
      // milliseconds
      this.highlightTimeout = null;
      this.hasCopied = false;
      this.currentHighlightedResponse = null;
      this.currentGlowElement = null;
      this.lastCopyStrategy = null;
      this.lastCopyMouseX = 0;
      this.lastCopyMouseY = 0;
      this.lastCopyScrollPosition = 0;
      this.lastCursorElement = null;
    }
    /**
     * Update mouse cursor position
     */
    updateMousePosition(x, y) {
      this.mouseX = x;
      this.mouseY = y;
      this.hasMouseMoved = true;
    }
    /**
     * Reset the copy state when key is released
     */
    resetCopyState() {
      if (!this.hasCopied) {
        return;
      }
      if (this.highlightTimeout) {
        return;
      }
      this.highlightTimeout = window.setTimeout(() => {
        document.querySelectorAll(".kity-code-copied").forEach((el) => {
          el.classList.remove("kity-code-copied");
        });
        this.clearResponseHighlight();
        this.highlightTimeout = null;
        this.hasCopied = false;
      }, this.MIN_HIGHLIGHT_DURATION);
    }
    /**
     * Copy code or text from the message under cursor, or copy selected text if any
     */
    copySelected() {
      console.log("[Kity] copySelected called");
      if (this.hasCopied) {
        console.log("[Kity] Already copied during this key hold");
        return;
      }
      const selection = window.getSelection();
      const selectedText = selection?.toString().trim();
      if (selectedText && selection && selection.rangeCount > 0) {
        const range = selection.getRangeAt(0);
        const container = range.commonAncestorContainer;
        let current = container.parentElement;
        let isInCodeBlock = false;
        while (current && current !== document.body) {
          if (current.tagName === "PRE") {
            isInCodeBlock = true;
            break;
          }
          current = current.parentElement;
        }
        if (!isInCodeBlock) {
          console.log("[Kity] User has selected text, copying selection");
          this.copyTextToClipboard(selectedText);
          this.hasCopied = true;
          return;
        }
        console.log("[Kity] Selection is inside code block, ignoring and using canvas copy");
      }
      console.log("[Kity] No text selected, using cursor-based copying");
      const cursorMessage = this.getMessageAtCursor();
      if (!cursorMessage) {
        const cachedStrategy = this.getCachedStrategy();
        if (cachedStrategy) {
          console.log("[Kity] Reusing last copy target");
          this.executeCopyStrategy(cachedStrategy);
          return;
        }
      }
      const targetMessage = cursorMessage || this.getFocusedMessage() || this.getBestViewportMessage();
      if (!targetMessage) {
        console.log("[Kity] No target message resolved for copy");
        return;
      }
      console.log("[Kity] Resolved message for copy");
      const strategy = this.determineCopyStrategy(targetMessage, cursorMessage);
      this.executeCopyStrategy(strategy);
      this.cacheStrategy(strategy);
    }
    /**
     * Get the message element directly under the cursor
     * Returns null if cursor is not over a valid message
     */
    getMessageAtCursor() {
      const element = this.resolveElementAtCursor();
      let message = null;
      if (element) {
        this.lastCursorElement = element;
        if (!this.hasMouseMoved) {
          const rect = element.getBoundingClientRect();
          this.mouseX = rect.left + rect.width / 2;
          this.mouseY = rect.top + rect.height / 2;
          this.hasMouseMoved = true;
        }
        message = ChatGPTSelectors.findParentMessage(element);
      } else {
        this.lastCursorElement = null;
      }
      if (!message && this.isCursorInMainPane()) {
        message = this.getMessageByCursorY();
      }
      if (message) {
        const role = message.getAttribute("data-message-author-role") ?? "message";
        console.log(`[Kity] Found ${role} message at cursor`);
      } else {
        console.log("[Kity] No message container found at cursor");
      }
      return message;
    }
    resolveElementAtCursor() {
      if (this.hasMouseMoved) {
        return document.elementFromPoint(this.mouseX, this.mouseY);
      }
      const hovered = document.querySelectorAll(":hover");
      if (hovered.length > 0) {
        return hovered[hovered.length - 1];
      }
      return null;
    }
    getMessageByCursorY() {
      const messages = ChatGPTSelectors.getAllMessages();
      if (!messages.length) {
        return null;
      }
      const screenWidth = window.innerWidth;
      const safeX = Math.min(Math.max(this.mouseX, 0), screenWidth);
      for (const msg of messages) {
        if (!msg.isConnected) {
          continue;
        }
        const rect = msg.getBoundingClientRect();
        if (this.mouseY >= rect.top && this.mouseY <= rect.bottom) {
          const paddedLeft = rect.left - 200;
          const paddedRight = rect.right + 200;
          if (safeX >= paddedLeft && safeX <= paddedRight) {
            return msg;
          }
        }
      }
      return null;
    }
    isCursorInMainPane() {
      const main = ChatGPTSelectors.getMain();
      if (!main) {
        return false;
      }
      const rect = main.getBoundingClientRect();
      return this.mouseY >= rect.top && this.mouseY <= rect.bottom;
    }
    /**
     * Get currently focused message element if available
     */
    getFocusedMessage() {
      const focused = document.querySelector(".kity-focus");
      if (!focused) {
        return null;
      }
      if (ChatGPTSelectors.isMessageElement(focused)) {
        return focused;
      }
      if (focused instanceof HTMLElement) {
        const parentMessage = ChatGPTSelectors.findParentMessage(focused);
        if (parentMessage) {
          return parentMessage;
        }
      }
      return null;
    }
    /**
     * Pick the most visible message when cursor/focus are unavailable
     */
    getBestViewportMessage() {
      const messages = ChatGPTSelectors.getAllMessages();
      if (!messages.length) {
        return null;
      }
      const viewportCenter = window.innerHeight / 2;
      const coveragePreference = 0.05;
      let bestMessage = null;
      let bestCoverage = -1;
      let bestDistance = Infinity;
      messages.forEach((msg) => {
        if (!msg.isConnected) {
          return;
        }
        const rect = msg.getBoundingClientRect();
        if (rect.bottom <= 0 || rect.top >= window.innerHeight) {
          return;
        }
        const visibleHeight = this.getVisibleHeight(msg);
        if (visibleHeight <= 0) {
          return;
        }
        const coverage = visibleHeight / window.innerHeight;
        const center = rect.top + rect.height / 2;
        const distance = Math.abs(center - viewportCenter);
        const coverageImproved = coverage > bestCoverage + coveragePreference;
        const coverageComparable = Math.abs(coverage - bestCoverage) <= coveragePreference;
        if (coverageImproved || coverageComparable && distance < bestDistance) {
          bestMessage = msg;
          bestCoverage = coverage;
          bestDistance = distance;
        }
      });
      if (bestMessage) {
        console.log("[Kity] Using best-viewport message fallback");
      }
      return bestMessage;
    }
    /**
     * Determine whether to copy message text or a specific code block
     */
    determineCopyStrategy(selectedMessage, cursorMessage) {
      const codeBlocks = Array.from(selectedMessage.querySelectorAll("pre"));
      const origin = cursorMessage === selectedMessage ? "cursor" : "fallback";
      if (origin === "fallback" || codeBlocks.length === 0) {
        return { type: "text", message: selectedMessage, origin };
      }
      const cursorIsInMessage = origin === "cursor";
      if (cursorIsInMessage) {
        const cursorBlock = this.getCodeBlockAtCursor(codeBlocks);
        if (cursorBlock) {
          console.log("[Kity] Cursor inside code block, prioritizing canvas copy");
          return { type: "code", message: selectedMessage, block: cursorBlock, origin };
        }
        console.log("[Kity] Cursor inside message text, copying full message");
        return { type: "text", message: selectedMessage, origin };
      }
      const { messageHeight, codeHeight } = this.measureVisibleContent(selectedMessage, codeBlocks);
      const plainHeight = Math.max(0, messageHeight - codeHeight);
      if (plainHeight >= codeHeight) {
        return { type: "text", message: selectedMessage, origin };
      }
      const dominantBlock = this.selectLargestVisibleCodeBlock(codeBlocks) || this.selectCodeBlockByViewport(codeBlocks) || codeBlocks[0];
      return {
        type: "code",
        message: selectedMessage,
        block: dominantBlock,
        origin
      };
    }
    /**
     * Execute the chosen copy strategy
     */
    executeCopyStrategy(strategy) {
      this.hasCopied = true;
      if (strategy.type === "text") {
        this.copyFullMessage(strategy.message);
        return;
      }
      const codeBlocks = Array.from(strategy.message.querySelectorAll("pre"));
      if (codeBlocks.length === 0) {
        console.warn("[Kity] Expected code blocks but none found, copying full message instead");
        this.copyFullMessage(strategy.message);
        return;
      }
      const highlightCodeOnly = strategy.origin === "cursor";
      this.copyCodeBlock(codeBlocks, strategy.message, strategy.block, highlightCodeOnly);
    }
    /**
     * Cache the last strategy so it can be reused if viewport state is unchanged
     */
    cacheStrategy(strategy) {
      this.lastCopyStrategy = strategy;
      this.lastCopyMouseX = this.mouseX;
      this.lastCopyMouseY = this.mouseY;
      this.lastCopyScrollPosition = this.getScrollPosition();
    }
    getCachedStrategy() {
      if (!this.lastCopyStrategy) {
        return null;
      }
      const sameMouse = this.lastCopyMouseX === this.mouseX && this.lastCopyMouseY === this.mouseY;
      const sameScroll = this.lastCopyScrollPosition === this.getScrollPosition();
      const messageConnected = this.lastCopyStrategy.message.isConnected;
      const blockConnected = this.lastCopyStrategy.type === "code" ? this.lastCopyStrategy.block.isConnected : true;
      if (sameMouse && sameScroll && messageConnected && blockConnected) {
        return this.lastCopyStrategy;
      }
      return null;
    }
    getScrollPosition() {
      const container = ChatGPTSelectors.getScrollContainer();
      if (container) {
        return container.scrollTop;
      }
      return window.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0;
    }
    /**
     * Copy a code block from the selected message
     */
    copyCodeBlock(codeBlocks, selectedMessage, preferredBlock, highlightCodeOnly) {
      console.log("[Kity] Found", codeBlocks.length, "code blocks");
      let targetBlock = preferredBlock || null;
      if (!targetBlock) {
        if (codeBlocks.length === 1) {
          targetBlock = codeBlocks[0];
        } else {
          targetBlock = this.selectCodeBlockByMouse(codeBlocks);
        }
      }
      if (!targetBlock) {
        targetBlock = codeBlocks[0];
      }
      if (targetBlock) {
        const blockIndex = codeBlocks.indexOf(targetBlock) + 1;
        const totalCodeBlocks = codeBlocks.length;
        if (highlightCodeOnly) {
          this.clearResponseHighlight();
        } else {
          this.highlightResponse(selectedMessage);
        }
        this.applyGlitterEffect(targetBlock);
        const copyButton = ChatGPTSelectors.findCopyButton(targetBlock);
        if (copyButton) {
          console.log("[Kity] Found copy button, clicking it");
          copyButton.click();
          setTimeout(() => {
            showToast(totalCodeBlocks > 1 ? `Copied canvas ${blockIndex}/${totalCodeBlocks}` : "Copied canvas");
          }, 50);
          return;
        } else {
          console.log("[Kity] No copy button found, falling back to text extraction");
          const textToCopy = targetBlock.textContent?.trim() || "";
          if (textToCopy) {
            const toastMessage = totalCodeBlocks > 1 ? `Copied canvas ${blockIndex}/${totalCodeBlocks}` : "Copied canvas";
            this.copyTextToClipboard(textToCopy, toastMessage);
            return;
          }
        }
      }
    }
    /**
     * Determine which portion of the message is most visible
     */
    measureVisibleContent(message, codeBlocks) {
      const messageHeight = this.getVisibleHeight(message);
      let codeHeight = 0;
      codeBlocks.forEach((block) => {
        codeHeight += this.getVisibleHeight(block);
      });
      codeHeight = Math.min(codeHeight, messageHeight);
      return { messageHeight, codeHeight };
    }
    getVisibleHeight(element) {
      const rect = element.getBoundingClientRect();
      const visibleTop = Math.max(rect.top, 0);
      const visibleBottom = Math.min(rect.bottom, window.innerHeight);
      return Math.max(0, visibleBottom - visibleTop);
    }
    selectLargestVisibleCodeBlock(codeBlocks) {
      let targetBlock = null;
      let maxVisibleHeight = 0;
      codeBlocks.forEach((block) => {
        const visibleHeight = this.getVisibleHeight(block);
        if (visibleHeight > maxVisibleHeight) {
          maxVisibleHeight = visibleHeight;
          targetBlock = block;
        }
      });
      return targetBlock;
    }
    getCodeBlockAtCursor(codeBlocks) {
      const matchByY = (block) => {
        const rect = block.getBoundingClientRect();
        return this.mouseY >= rect.top && this.mouseY <= rect.bottom;
      };
      if (this.hasMouseMoved) {
        for (const block of codeBlocks) {
          if (matchByY(block)) {
            return block;
          }
        }
      }
      if (this.lastCursorElement instanceof HTMLElement) {
        const hoveredBlock = ChatGPTSelectors.findParentCodeBlock(this.lastCursorElement);
        if (hoveredBlock && codeBlocks.includes(hoveredBlock)) {
          return hoveredBlock;
        }
      }
      return null;
    }
    /**
     * Select the appropriate code block based on mouse position
     */
    selectCodeBlockByMouse(codeBlocks) {
      let targetBlock = this.getCodeBlockAtCursor(codeBlocks);
      if (targetBlock) {
        console.log("[Kity] Mouse is inside code block");
        return targetBlock;
      }
      if (!targetBlock) {
        let minDistance = Infinity;
        codeBlocks.forEach((block, index) => {
          const rect = block.getBoundingClientRect();
          const closestX = Math.max(rect.left, Math.min(this.mouseX, rect.right));
          const closestY = Math.max(rect.top, Math.min(this.mouseY, rect.bottom));
          const distance = Math.sqrt(
            Math.pow(closestX - this.mouseX, 2) + Math.pow(closestY - this.mouseY, 2)
          );
          console.log(`[Kity] Code block ${index + 1} distance from mouse:`, distance);
          if (distance < minDistance) {
            minDistance = distance;
            targetBlock = block;
          }
        });
        if (minDistance > this.DISTANCE_THRESHOLD) {
          console.log("[Kity] Mouse too far from any block, using viewport center");
          targetBlock = this.selectCodeBlockByViewport(codeBlocks);
        }
      }
      return targetBlock;
    }
    /**
     * Select code block closest to viewport center
     */
    selectCodeBlockByViewport(codeBlocks) {
      let targetBlock = null;
      let minDistance = Infinity;
      const viewportCenterY = window.innerHeight / 2;
      codeBlocks.forEach((block) => {
        const rect = block.getBoundingClientRect();
        const blockCenterY = rect.top + rect.height / 2;
        const distance = Math.abs(blockCenterY - viewportCenterY);
        if (distance < minDistance) {
          minDistance = distance;
          targetBlock = block;
        }
      });
      return targetBlock;
    }
    /**
     * Copy the full message text
     */
    copyFullMessage(selectedMessage) {
      console.log("[Kity] No code blocks found, copying full message");
      const textToCopy = selectedMessage.textContent || "";
      if (!textToCopy.trim()) {
        console.log("[Kity] Selected message is empty");
        showToast("Selected message is empty");
        return;
      }
      this.highlightResponse(selectedMessage);
      const toastMessage = this.buildMessageCopyToast(selectedMessage);
      this.copyTextToClipboard(textToCopy.trim(), toastMessage);
    }
    buildMessageCopyToast(message) {
      const role = this.getMessageRole(message);
      if (role !== "assistant" && role !== "user") {
        return "Copied";
      }
      const messages = ChatGPTSelectors.getAllMessages();
      const roleMessages = messages.filter((msg) => this.getMessageRole(msg) === role);
      const index = roleMessages.indexOf(message);
      const position = index >= 0 ? index + 1 : roleMessages.length || 1;
      const total = roleMessages.length || position;
      if (role === "assistant") {
        return `Copied response ${position}/${total}`;
      }
      return `Copied request ${position}/${total}`;
    }
    getMessageRole(message) {
      const direct = message.getAttribute("data-message-author-role");
      if (direct) {
        return direct.toLowerCase();
      }
      const idAttr = message.getAttribute("data-message-id");
      if (idAttr && idAttr.startsWith("assistant-")) {
        return "assistant";
      }
      if (idAttr && idAttr.startsWith("user-")) {
        return "user";
      }
      return (message.getAttribute("role") || "").toLowerCase();
    }
    /**
     * Copy text to clipboard using multiple methods
     */
    copyTextToClipboard(text, toastMessage = "Copied") {
      console.log("[Kity] Text to copy:", text.substring(0, 100) + "...");
      try {
        const showSuccess = () => {
          showToast(toastMessage);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).then(() => {
            console.log("[Kity] Copied successfully via clipboard API");
            showSuccess();
          }).catch((err) => {
            console.error("[Kity] Clipboard API failed:", err);
            this.copyUsingExecCommand(text, toastMessage);
          });
        } else {
          console.log("[Kity] Clipboard API not available, using execCommand");
          this.copyUsingExecCommand(text, toastMessage);
        }
      } catch (err) {
        console.error("[Kity] Copy failed:", err);
        showToast("Failed to copy");
      }
    }
    /**
     * Copy text using legacy execCommand method
     */
    copyUsingExecCommand(text, successMessage = "Copied") {
      const textarea = document.createElement("textarea");
      textarea.value = text;
      textarea.style.position = "fixed";
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.select();
      try {
        const successful = document.execCommand("copy");
        if (successful) {
          console.log("[Kity] Copied successfully via execCommand");
          showToast(successMessage);
        } else {
          console.error("[Kity] execCommand copy failed");
          showToast("Failed to copy");
        }
      } catch (err) {
        console.error("[Kity] execCommand error:", err);
        showToast("Failed to copy");
      } finally {
        document.body.removeChild(textarea);
      }
    }
    /**
     * Apply green highlight animation to code block
     */
    applyGlitterEffect(element) {
      this.currentGlowElement = element;
      element.classList.add("kity-code-copied");
    }
    /**
     * Highlight the copied response element
     */
    highlightResponse(message) {
      const target = this.getHighlightTarget(message);
      if (this.currentHighlightedResponse !== target) {
        this.clearResponseHighlight();
        this.currentHighlightedResponse = target;
      }
      target.classList.add("kity-response-copied");
    }
    clearResponseHighlight() {
      if (this.currentHighlightedResponse) {
        this.currentHighlightedResponse.classList.remove("kity-response-copied");
        this.currentHighlightedResponse = null;
      }
    }
    /**
     * Prefer the smallest content container for highlight so the glow matches text width
     */
    getHighlightTarget(message) {
      const preferSelectors = [
        ".markdown",
        ".prose",
        "[data-message-author-role] .whitespace-pre-wrap",
        "[data-message-author-role] .text-base"
      ];
      for (const selector of preferSelectors) {
        const el = message.querySelector(selector);
        if (el) return el;
      }
      const nonEmptyDiv = Array.from(message.querySelectorAll("div")).find(
        (el) => el.textContent?.trim()
      );
      return nonEmptyDiv ?? message;
    }
  };

  // src/content/adapters/chatgpt/trackers.ts
  var Trackers = class {
    /**
     * Setup click tracking for messages and code blocks
     */
    setupClickTracking(onMessageClick) {
      this.onMessageClick = onMessageClick;
      document.addEventListener("click", (event) => {
        const target = event.target;
        const codeBlock = ChatGPTSelectors.findParentCodeBlock(target);
        if (codeBlock) {
          console.log("[Kity] Clicked code block tracked");
        }
        const messageElement = ChatGPTSelectors.findParentMessage(target);
        if (messageElement) {
          this.onMessageClick?.(messageElement);
          console.log("[Kity] Clicked message tracked:", messageElement.getAttribute("data-message-author-role"));
        } else {
          console.log("[Kity] Click target:", target.tagName, target.className);
        }
      });
    }
    /**
     * Setup mouse movement tracking
     */
    setupMouseTracking(onMouseMove) {
      this.onMouseMove = onMouseMove;
      document.addEventListener("mousemove", (event) => {
        this.onMouseMove?.(event.clientX, event.clientY);
      });
    }
  };

  // src/content/adapters/chatgpt/main.gpt.ts
  var ChatGPTAdapter = class {
    constructor() {
      this.id = "gpt";
      this.supports = {
        sidebar: true,
        mainPane: true,
        input: true,
        userInputsNav: true
      };
      // State
      this.lastFocusedPane = "main";
      this.scrollManager = new ScrollManager();
      this.sidebarNavigator = new SidebarNavigator();
      this.userMessageNavigator = new UserMessageNavigator();
      this.textSelector = new TextSelector();
      this.codeCopier = new CodeCopier();
      this.trackers = new Trackers();
    }
    init() {
      console.log("[Kity] ChatGPT adapter initialized");
      this.trackers.setupMouseTracking((x, y) => {
        this.codeCopier.updateMousePosition(x, y);
      });
    }
    // ==================== Pane Navigation ====================
    focusSidebar() {
      this.sidebarNavigator.focusSidebar();
      this.lastFocusedPane = "sidebar";
    }
    focusMain() {
      const main = ChatGPTSelectors.getMain();
      if (main) {
        setFocusRing(main);
        this.lastFocusedPane = "main";
      } else {
        showToast("No main pane found");
      }
    }
    // ==================== Sidebar Navigation ====================
    navigateUp() {
      this.sidebarNavigator.navigateUp();
    }
    navigateDown() {
      this.sidebarNavigator.navigateDown();
    }
    // ==================== User Message Navigation ====================
    prevUser() {
      this.userMessageNavigator.prevUser();
    }
    nextUser() {
      this.userMessageNavigator.nextUser();
    }
    // ==================== Jump Navigation ====================
    jumpToFirst() {
      this.userMessageNavigator.switchToGeneralNav();
      const main = ChatGPTSelectors.getMain();
      if (main) {
        const messages = ChatGPTSelectors.getAllMessages(150);
        if (messages.length > 0) {
          setFocusRing(messages[0]);
          showToast("Earliest message");
        } else {
          showToast("No messages found");
        }
      } else {
        showToast("No main pane found");
      }
    }
    jumpToLast() {
      this.userMessageNavigator.switchToGeneralNav();
      const main = ChatGPTSelectors.getMain();
      if (main) {
        const allMessages = Array.from(
          main.querySelectorAll("[data-message-author-role], [data-message-id], article")
        ).filter((msg) => {
          const rect = msg.getBoundingClientRect();
          const isInInputArea = rect.top > window.innerHeight - 100;
          const hasMessageRole = msg.hasAttribute("data-message-author-role") || msg.hasAttribute("data-message-id");
          return msg.textContent?.trim() && (hasMessageRole || !isInInputArea);
        });
        if (allMessages.length > 0) {
          setFocusRing(allMessages[allMessages.length - 1]);
          showToast("Latest message");
        } else {
          showToast("No messages found");
        }
      } else {
        showToast("No main pane found");
      }
    }
    // ==================== Text Selection ====================
    extendSelectionUp() {
      this.textSelector.extendSelectionUp();
    }
    extendSelectionDown() {
      this.textSelector.extendSelectionDown();
    }
    // ==================== Code Copying ====================
    copySelected() {
      this.codeCopier.copySelected();
    }
    resetCopyGlow() {
      this.codeCopier.resetCopyState();
    }
    // ==================== Scrolling ====================
    startScroll(direction) {
      this.scrollManager.startScroll(direction);
    }
    stopScroll() {
      this.scrollManager.stopScroll();
    }
  };

  // src/content/adapters/claude/claude-selectors.ts
  var ClaudeSelectors = class {
    /**
     * Main application surface
     */
    static getMain() {
      return document.querySelector("main") || document.querySelector('[role="main"]') || document.querySelector('[data-testid="main-content"]');
    }
    /**
     * Scrolling container for conversations
     */
    static getScrollContainer() {
      if (this.cachedScrollContainer && document.contains(this.cachedScrollContainer) && this.isScrollableElement(this.cachedScrollContainer)) {
        return this.cachedScrollContainer;
      }
      const container = this.findScrollContainer();
      if (container) {
        this.cachedScrollContainer = container;
        return container;
      }
      const fallback = document.scrollingElement;
      if (fallback) {
        this.cachedScrollContainer = fallback;
        return fallback;
      }
      return document.body;
    }
    /**
     * Manually clear cached reference if DOM changes drastically
     */
    static resetScrollCache() {
      this.cachedScrollContainer = null;
    }
    static findScrollContainer() {
      const main = this.getMain();
      const searchRoots = [main, document];
      for (const root of searchRoots) {
        if (!root) {
          continue;
        }
        for (const selector of this.SCROLL_CONTAINER_SELECTORS) {
          const candidate = root.querySelector?.(selector);
          if (candidate instanceof HTMLElement && this.isScrollableElement(candidate)) {
            return candidate;
          }
        }
      }
      const scrollableWithinMain = this.findScrollableDescendant(main);
      if (scrollableWithinMain) {
        return scrollableWithinMain;
      }
      const scrollableInDocument = this.findScrollableDescendant(document.body);
      if (scrollableInDocument) {
        return scrollableInDocument;
      }
      return null;
    }
    static findScrollableDescendant(root) {
      if (!root) {
        return null;
      }
      const candidates = [];
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
      let currentNode = root;
      const visit = (node) => {
        if (!node) {
          return;
        }
        if (node instanceof HTMLElement && this.isScrollableElement(node)) {
          candidates.push(node);
        }
      };
      visit(currentNode);
      while (currentNode = walker.nextNode()) {
        visit(currentNode);
      }
      if (candidates.length === 0) {
        return null;
      }
      candidates.sort((a, b) => b.clientHeight - a.clientHeight);
      return candidates[0];
    }
    static isScrollableElement(element) {
      if (!element) {
        return false;
      }
      const style = window.getComputedStyle(element);
      const overflowAllowsScroll = style.overflowY === "auto" || style.overflowY === "scroll";
      const hasScrollableContent = element.scrollHeight - element.clientHeight > 32;
      return overflowAllowsScroll && hasScrollableContent;
    }
  };
  ClaudeSelectors.SCROLL_CONTAINER_SELECTORS = [
    '[data-testid="conversation-view"]',
    '[data-testid="scroll-container"]',
    '[data-testid="chat-scroll-container"]',
    '[data-testid="conversation-list"]',
    '[data-scroll-container="true"]',
    '[data-testid="chat-history"]',
    '[data-testid="messages-scroll"]',
    '[data-testid="scrollable"]',
    '[data-testid*="Scroll"]',
    '[data-testid*="scroll"]',
    ".overflow-y-auto",
    '[class*="overflow-y-auto"]',
    '[class*="scroll"]',
    '[class*="Scroll"]'
  ];
  ClaudeSelectors.cachedScrollContainer = null;

  // src/content/adapters/claude/claude-scroll-manager.ts
  var ClaudeScrollManager = class {
    constructor() {
      this.isScrolling = false;
      this.scrollDirection = null;
      this.scrollSpeed = 0;
      this.scrollAnimationId = null;
      this.maxScrollSpeed = 45;
      this.scrollAcceleration = 2;
      this.scrollDeceleration = 3;
    }
    startScroll(direction) {
      this.scrollDirection = direction;
      this.isScrolling = true;
      if (this.scrollAnimationId === null) {
        this.scrollSpeed = 0;
        this.runScrollAnimation();
      }
    }
    stopScroll() {
      this.isScrolling = false;
    }
    runScrollAnimation() {
      const scrollContainer = ClaudeSelectors.getScrollContainer();
      if (!scrollContainer) {
        console.log("[Kity] Claude scroll container not found");
        this.scrollAnimationId = null;
        return;
      }
      if (this.isScrolling) {
        this.scrollSpeed = Math.min(this.scrollSpeed + this.scrollAcceleration, this.maxScrollSpeed);
      } else {
        this.scrollSpeed = Math.max(this.scrollSpeed - this.scrollDeceleration, 0);
      }
      if (this.scrollDirection === "up") {
        scrollContainer.scrollTop -= this.scrollSpeed;
      } else if (this.scrollDirection === "down") {
        scrollContainer.scrollTop += this.scrollSpeed;
      }
      if (this.scrollSpeed > 0) {
        this.scrollAnimationId = requestAnimationFrame(() => this.runScrollAnimation());
      } else {
        this.scrollAnimationId = null;
        this.scrollDirection = null;
      }
    }
  };

  // src/content/adapters/claude/main.claude.ts
  var ClaudeAdapter = class {
    constructor() {
      this.id = "claude";
      this.supports = {
        mainPane: true
      };
      this.scrollManager = new ClaudeScrollManager();
    }
    init() {
      console.log("[Kity] Claude adapter initialized");
    }
    startScroll(direction) {
      this.scrollManager.startScroll(direction);
    }
    stopScroll() {
      this.scrollManager.stopScroll();
    }
  };

  // src/content/adapters/gmail/dom-explorer.ts
  var GmailDOMExplorer = class {
    /**
     * Log all elements with role attributes (helps identify key UI components)
     */
    static logRoleElements() {
      console.log("[Gmail DOM Explorer] === Elements with role attributes ===");
      const elements = document.querySelectorAll("[role]");
      elements.forEach((el, index) => {
        const role = el.getAttribute("role");
        const ariaLabel = el.getAttribute("aria-label");
        const classes = el.className;
        const id = el.id;
        console.log(`${index}: role="${role}" aria-label="${ariaLabel}" id="${id}" classes="${classes}"`);
      });
    }
    /**
     * Log the main navigation/sidebar structure
     */
    static logNavigation() {
      console.log("[Gmail DOM Explorer] === Navigation/Sidebar ===");
      const nav = document.querySelector("nav") || document.querySelector('[role="navigation"]');
      if (nav) {
        console.log("Found nav element:", nav);
        console.log("Nav classes:", nav.className);
        console.log("Nav children:", nav.children.length);
        Array.from(nav.children).forEach((child, i) => {
          console.log(`  Child ${i}:`, child.tagName, child.className, child.textContent?.trim().substring(0, 30));
        });
      } else {
        console.log("No nav element found");
      }
    }
    /**
     * Log the main content area structure
     */
    static logMainContent() {
      console.log("[Gmail DOM Explorer] === Main Content Area ===");
      const main = document.querySelector("main") || document.querySelector('[role="main"]');
      if (main) {
        console.log("Found main element:", main);
        console.log("Main classes:", main.className);
        console.log("Main children:", main.children.length);
      } else {
        console.log("No main element found, checking for table rows...");
        const rows = document.querySelectorAll('tr[role="row"]');
        console.log("Found", rows.length, "email rows");
        if (rows.length > 0) {
          console.log("First row:", rows[0]);
          console.log("First row classes:", rows[0].className);
        }
      }
    }
    /**
     * Log all email row elements
     */
    static logEmailRows() {
      console.log("[Gmail DOM Explorer] === Email Rows ===");
      const selectors = [
        'tr[role="row"]',
        "tr.zA",
        "tr[data-legacy-message-id]",
        ".zA",
        "[data-message-id]"
      ];
      selectors.forEach((selector) => {
        const elements = document.querySelectorAll(selector);
        if (elements.length > 0) {
          console.log(`Selector "${selector}" found ${elements.length} elements`);
          const first = elements[0];
          console.log("  First element:", first);
          console.log("  Classes:", first.className);
          console.log("  Attributes:", Array.from(first.attributes).map((a) => `${a.name}="${a.value}"`).join(", "));
        }
      });
    }
    /**
     * Log currently focused/selected element
     */
    static logFocusedElement() {
      console.log("[Gmail DOM Explorer] === Focused Element ===");
      const focused = document.activeElement;
      console.log("Active element:", focused);
      console.log("Tag:", focused?.tagName);
      console.log("Classes:", focused?.className);
      console.log("ID:", focused?.id);
      const selected = document.querySelector('[aria-selected="true"]') || document.querySelector(".x7") || document.querySelector('[class*="selected"]');
      if (selected) {
        console.log("Selected element:", selected);
        console.log("Selected classes:", selected.className);
      }
    }
    /**
     * Log sidebar buttons and links
     */
    static logSidebarButtons() {
      console.log("[Gmail DOM Explorer] === Sidebar Buttons ===");
      const sidebar = document.querySelector("nav") || document.querySelector(".aim");
      if (!sidebar) {
        console.log("Sidebar not found");
        return;
      }
      const buttons = sidebar.querySelectorAll('a, button, [role="button"]');
      console.log(`Found ${buttons.length} clickable elements in sidebar`);
      buttons.forEach((btn, i) => {
        const text = btn.textContent?.trim();
        const ariaLabel = btn.getAttribute("aria-label");
        const href = btn.href;
        console.log(`${i}: "${text}" aria-label="${ariaLabel}" href="${href}"`);
      });
    }
    /**
     * Run all explorers
     */
    static exploreAll() {
      console.group("%c=== GMAIL DOM EXPLORATION ===", "color: #FF6B6B; font-size: 16px; font-weight: bold;");
      console.group("%cNavigation/Sidebar", "color: #4ECDC4; font-weight: bold;");
      this.logNavigation();
      console.groupEnd();
      console.group("%cMain Content Area", "color: #4ECDC4; font-weight: bold;");
      this.logMainContent();
      console.groupEnd();
      console.group("%cEmail Rows", "color: #4ECDC4; font-weight: bold;");
      this.logEmailRows();
      console.groupEnd();
      console.group("%cSidebar Buttons", "color: #4ECDC4; font-weight: bold;");
      this.logSidebarButtons();
      console.groupEnd();
      console.group("%cFocused Element", "color: #4ECDC4; font-weight: bold;");
      this.logFocusedElement();
      console.groupEnd();
      console.group("%cRole Elements", "color: #4ECDC4; font-weight: bold;");
      this.logRoleElements();
      console.groupEnd();
      console.groupEnd();
    }
    /**
     * Make explorer available globally for console use
     */
    static expose() {
      window.gmailExplorer = this;
    }
  };

  // src/content/adapters/gmail/selectors.ts
  var GmailSelectors = class {
    /**
     * Get the sidebar navigation element
     */
    static getSidebar() {
      return document.querySelector('[role="navigation"]') || document.querySelector("nav") || document.querySelector(".aim");
    }
    /**
     * Get the main content pane
     */
    static getMain() {
      return document.querySelector('[role="main"]') || document.querySelector("main");
    }
    /**
     * Get all email rows in the inbox
     */
    static getEmailRows() {
      const rows = Array.from(document.querySelectorAll("tr.zA"));
      if (rows.length === 0) {
        return Array.from(document.querySelectorAll('tr[role="row"]'));
      }
      return rows;
    }
    /**
     * Get the currently selected/focused email row
     */
    static getCurrentEmailRow() {
      return document.querySelector('[aria-selected="true"]') || document.querySelector(".x7") || document.querySelector("tr.zA.btb");
    }
    /**
     * Get the scroll container
     */
    static getScrollContainer() {
      const main = this.getMain();
      if (!main) return null;
      return main.querySelector(".Tm.aeJ") || main;
    }
    /**
     * Get all focusable elements in the sidebar
     */
    static getSidebarFocusableElements() {
      const sidebar = this.getSidebar();
      if (!sidebar) return [];
      const elements = Array.from(
        sidebar.querySelectorAll('a, button, [role="button"]')
      );
      return elements.filter((el) => {
        const text = el.textContent?.trim();
        return text && text.length > 0;
      });
    }
    /**
     * Check if element is inside the sidebar
     */
    static isInSidebar(element) {
      const sidebar = this.getSidebar();
      return !!(sidebar && sidebar.contains(element));
    }
    /**
     * Check if element is inside the main pane
     */
    static isInMain(element) {
      const main = this.getMain();
      return !!(main && main.contains(element));
    }
  };

  // src/content/adapters/gmail/sidebar-navigator.ts
  var SidebarNavigator2 = class {
    /**
     * Focus the sidebar
     */
    focusSidebar() {
      const sidebar = GmailSelectors.getSidebar();
      if (!sidebar) {
        showToast("No sidebar found");
        return;
      }
      const focusableElements = GmailSelectors.getSidebarFocusableElements();
      if (focusableElements.length > 0) {
        setFocusRing(focusableElements[0]);
      } else {
        setFocusRing(sidebar);
      }
    }
    /**
     * Navigate up in the sidebar
     */
    navigateUp() {
      const focused = document.querySelector(".kity-focus");
      if (!focused) return;
      const prev = this.getPreviousFocusable(focused);
      if (!prev) return;
      setFocusRing(prev);
    }
    /**
     * Navigate down in the sidebar
     */
    navigateDown() {
      const focused = document.querySelector(".kity-focus");
      if (!focused) return;
      const next = this.getNextFocusable(focused);
      if (!next) return;
      setFocusRing(next);
    }
    /**
     * Get the previous focusable element in the sidebar
     */
    getPreviousFocusable(element) {
      const allFocusable = GmailSelectors.getSidebarFocusableElements();
      const currentIndex = allFocusable.indexOf(element);
      if (currentIndex > 0) {
        return allFocusable[currentIndex - 1];
      }
      return null;
    }
    /**
     * Get the next focusable element in the sidebar
     */
    getNextFocusable(element) {
      const allFocusable = GmailSelectors.getSidebarFocusableElements();
      const currentIndex = allFocusable.indexOf(element);
      if (currentIndex >= 0 && currentIndex < allFocusable.length - 1) {
        return allFocusable[currentIndex + 1];
      }
      return null;
    }
  };

  // src/content/adapters/gmail/main.gmail.ts
  var GmailAdapter = class {
    constructor() {
      this.id = "gmail";
      this.supports = {
        sidebar: true,
        mainPane: true,
        input: true
      };
      // State
      this.lastFocusedPane = "main";
      this.sidebarNavigator = new SidebarNavigator2();
    }
    init() {
      console.log(
        "%c[Kity] Gmail adapter initialized",
        "color: #4CAF50; font-weight: bold; font-size: 14px;"
      );
      console.log("[Kity] Version: 1.0.0 | Site: Gmail | Adapter: gmail");
      GmailDOMExplorer.expose();
    }
    // ==================== Pane Navigation ====================
    focusSidebar() {
      this.sidebarNavigator.focusSidebar();
      this.lastFocusedPane = "sidebar";
    }
    focusMain() {
      const main = GmailSelectors.getMain();
      if (main) {
        setFocusRing(main);
        this.lastFocusedPane = "main";
      } else {
        showToast("No main pane found");
      }
    }
    // ==================== Navigation ====================
    navigateUp() {
      showToast("Navigate up not implemented yet");
    }
    navigateDown() {
      showToast("Navigate down not implemented yet");
    }
    // ==================== User Message Navigation ====================
    prevUser() {
      showToast("Previous email not implemented yet");
    }
    nextUser() {
      showToast("Next email not implemented yet");
    }
    // ==================== Selection Extension ====================
    extendSelectionUp() {
      showToast("Extend selection up not implemented yet");
    }
    extendSelectionDown() {
      showToast("Extend selection down not implemented yet");
    }
    // ==================== Jump Navigation ====================
    jumpToFirst() {
      showToast("Jump to first not implemented yet");
    }
    jumpToLast() {
      showToast("Jump to last not implemented yet");
    }
    // ==================== Copying ====================
    copySelected() {
      showToast("Copy not implemented yet");
    }
    // ==================== Scrolling ====================
    startScroll(direction) {
      console.log("[Kity] Start scroll:", direction);
    }
    stopScroll() {
      console.log("[Kity] Stop scroll");
    }
  };

  // src/content/adapters/google-search/selectors.ts
  var GoogleSearchSelectors = class {
    /**
     * Main results container
     */
    static getMain() {
      return document.querySelector("#search") || document.querySelector("main");
    }
    /**
     * Scroll container for smooth scrolling
     */
    static getScrollContainer() {
      return document.scrollingElement || document.documentElement || document.body;
    }
  };

  // src/content/adapters/google-search/scroll-manager.ts
  var ScrollManager2 = class {
    constructor() {
      this.isScrolling = false;
      this.scrollDirection = null;
      this.scrollSpeed = 0;
      this.scrollAnimationId = null;
      this.maxScrollSpeed = 50;
      this.scrollAcceleration = 2;
      this.scrollDeceleration = 3;
    }
    startScroll(direction) {
      this.scrollDirection = direction;
      this.isScrolling = true;
      if (this.scrollAnimationId === null) {
        this.scrollSpeed = 0;
        this.runScrollAnimation();
      }
    }
    stopScroll() {
      this.isScrolling = false;
    }
    runScrollAnimation() {
      const scrollContainer = GoogleSearchSelectors.getScrollContainer();
      if (!scrollContainer) {
        console.log("[Kity] [Google] Scroll container not found");
        this.scrollAnimationId = null;
        return;
      }
      if (this.isScrolling) {
        this.scrollSpeed = Math.min(this.scrollSpeed + this.scrollAcceleration, this.maxScrollSpeed);
      } else {
        this.scrollSpeed = Math.max(this.scrollSpeed - this.scrollDeceleration, 0);
      }
      const isWindowScroll = scrollContainer === document.scrollingElement || scrollContainer === document.documentElement || scrollContainer === document.body;
      if (this.scrollDirection === "up") {
        if (isWindowScroll) {
          window.scrollBy(0, -this.scrollSpeed);
        } else {
          scrollContainer.scrollTop -= this.scrollSpeed;
        }
      } else if (this.scrollDirection === "down") {
        if (isWindowScroll) {
          window.scrollBy(0, this.scrollSpeed);
        } else {
          scrollContainer.scrollTop += this.scrollSpeed;
        }
      }
      if (this.scrollSpeed > 0) {
        this.scrollAnimationId = requestAnimationFrame(() => this.runScrollAnimation());
      } else {
        this.scrollAnimationId = null;
        this.scrollDirection = null;
      }
    }
  };

  // src/content/adapters/google-search/main.google.ts
  var GoogleSearchAdapter = class {
    constructor() {
      this.id = "google";
      this.supports = {
        sidebar: false,
        mainPane: true,
        input: false
      };
      this.scrollManager = new ScrollManager2();
    }
    init() {
      console.log("%c[Kity] Google Search adapter initialized", "color: #4285F4; font-weight: bold;");
    }
    startScroll(direction) {
      this.scrollManager.startScroll(direction);
    }
    stopScroll() {
      this.scrollManager.stopScroll();
    }
    focusSidebar() {
      showToast("No sidebar available on Google Search");
    }
    focusMain() {
      const main = GoogleSearchSelectors.getMain();
      if (main) {
        setFocusRing(main);
        window.setTimeout(() => {
          main.classList.remove("kity-focus");
        }, 400);
      } else {
        showToast("No results area found");
      }
    }
  };

  // src/content/adapters/google-drive/selectors.ts
  var GoogleDriveSelectors = class {
    /**
     * Main scrollable container in Drive
     */
    static getScrollContainer() {
      return document.querySelector(".a-s-T") || document.scrollingElement || document.documentElement;
    }
    /**
     * Main view area
     */
    static getMain() {
      return document.querySelector('div[role="main"]') || document.querySelector(".drive-view");
    }
  };

  // src/content/adapters/google-drive/scroll-manager.ts
  var ScrollManager3 = class {
    constructor() {
      this.isScrolling = false;
      this.scrollDirection = null;
      this.scrollSpeed = 0;
      this.scrollAnimationId = null;
      this.maxScrollSpeed = 50;
      this.scrollAcceleration = 2;
      this.scrollDeceleration = 3;
    }
    startScroll(direction) {
      this.scrollDirection = direction;
      this.isScrolling = true;
      if (this.scrollAnimationId === null) {
        this.scrollSpeed = 0;
        this.runScrollAnimation();
      }
    }
    stopScroll() {
      this.isScrolling = false;
    }
    runScrollAnimation() {
      const scrollContainer = GoogleDriveSelectors.getScrollContainer();
      if (!scrollContainer) {
        console.warn("[Kity][GDrive] Scroll container not found");
        this.scrollAnimationId = null;
        return;
      }
      if (this.isScrolling) {
        this.scrollSpeed = Math.min(this.scrollSpeed + this.scrollAcceleration, this.maxScrollSpeed);
      } else {
        this.scrollSpeed = Math.max(this.scrollSpeed - this.scrollDeceleration, 0);
      }
      const isWindowScroll = scrollContainer === document.scrollingElement || scrollContainer === document.documentElement || scrollContainer === document.body;
      if (this.scrollDirection === "up") {
        if (isWindowScroll) {
          window.scrollBy(0, -this.scrollSpeed);
        } else {
          scrollContainer.scrollTop -= this.scrollSpeed;
        }
      } else if (this.scrollDirection === "down") {
        if (isWindowScroll) {
          window.scrollBy(0, this.scrollSpeed);
        } else {
          scrollContainer.scrollTop += this.scrollSpeed;
        }
      }
      if (this.scrollSpeed > 0) {
        this.scrollAnimationId = requestAnimationFrame(() => this.runScrollAnimation());
      } else {
        this.scrollAnimationId = null;
        this.scrollDirection = null;
      }
    }
  };

  // src/content/adapters/google-drive/main.gdrive.ts
  var GoogleDriveAdapter = class {
    constructor() {
      this.id = "gdrive";
      this.supports = {
        sidebar: false,
        mainPane: true
      };
      this.scrollManager = new ScrollManager3();
    }
    init() {
      console.log("%c[Kity] Google Drive adapter initialized", "color: #0F9D58; font-weight: bold;");
    }
    startScroll(direction) {
      this.scrollManager.startScroll(direction);
    }
    stopScroll() {
      this.scrollManager.stopScroll();
    }
    focusSidebar() {
      showToast("No sidebar available on Google Drive");
    }
    focusMain() {
      const main = GoogleDriveSelectors.getMain();
      if (main) {
        setFocusRing(main);
        window.setTimeout(() => main.classList.remove("kity-focus"), 400);
      } else {
        showToast("No Drive view found");
      }
    }
  };

  // src/content/adapters/wikipedia/selectors.ts
  var WikipediaSelectors = class {
    static getScrollContainer() {
      return document.scrollingElement || document.documentElement || document.body;
    }
    static getMain() {
      return document.querySelector("#content") || document.querySelector("main") || document.body;
    }
  };

  // src/content/adapters/wikipedia/scroll-manager.ts
  var ScrollManager4 = class {
    constructor() {
      this.isScrolling = false;
      this.scrollDirection = null;
      this.scrollSpeed = 0;
      this.scrollAnimationId = null;
      this.maxScrollSpeed = 50;
      this.scrollAcceleration = 2;
      this.scrollDeceleration = 3;
    }
    startScroll(direction) {
      this.scrollDirection = direction;
      this.isScrolling = true;
      if (this.scrollAnimationId === null) {
        this.scrollSpeed = 0;
        this.runScrollAnimation();
      }
    }
    stopScroll() {
      this.isScrolling = false;
    }
    runScrollAnimation() {
      const scrollContainer = WikipediaSelectors.getScrollContainer();
      if (!scrollContainer) {
        console.warn("[Kity][Wikipedia] Scroll container not found");
        this.scrollAnimationId = null;
        return;
      }
      if (this.isScrolling) {
        this.scrollSpeed = Math.min(this.scrollSpeed + this.scrollAcceleration, this.maxScrollSpeed);
      } else {
        this.scrollSpeed = Math.max(this.scrollSpeed - this.scrollDeceleration, 0);
      }
      if (this.scrollDirection === "up") {
        window.scrollBy(0, -this.scrollSpeed);
      } else if (this.scrollDirection === "down") {
        window.scrollBy(0, this.scrollSpeed);
      }
      if (this.scrollSpeed > 0) {
        this.scrollAnimationId = requestAnimationFrame(() => this.runScrollAnimation());
      } else {
        this.scrollAnimationId = null;
        this.scrollDirection = null;
      }
    }
  };

  // src/content/adapters/wikipedia/main.wpedia.ts
  var WikipediaAdapter = class {
    constructor() {
      this.id = "wpedia";
      this.supports = {
        sidebar: false,
        mainPane: true
      };
      this.scrollManager = new ScrollManager4();
    }
    init() {
      console.log("%c[Kity] Wikipedia adapter initialized", "color: #3366cc; font-weight: bold;");
    }
    startScroll(direction) {
      this.scrollManager.startScroll(direction);
    }
    stopScroll() {
      this.scrollManager.stopScroll();
    }
    focusSidebar() {
      showToast("No sidebar navigation available");
    }
    focusMain() {
      const main = WikipediaSelectors.getMain();
      if (main) {
        setFocusRing(main);
        window.setTimeout(() => main.classList.remove("kity-focus"), 400);
      } else {
        showToast("No article content found");
      }
    }
  };

  // src/content/adapters/amazon/selectors.ts
  var AmazonSelectors = class {
    static getScrollContainer() {
      return document.scrollingElement || document.documentElement || document.body;
    }
    static getMain() {
      return document.querySelector("#search") || document.querySelector("#dp");
    }
  };

  // src/content/adapters/amazon/scroll-manager.ts
  var ScrollManager5 = class {
    constructor() {
      this.isScrolling = false;
      this.scrollDirection = null;
      this.scrollSpeed = 0;
      this.scrollAnimationId = null;
      this.maxScrollSpeed = 50;
      this.scrollAcceleration = 2;
      this.scrollDeceleration = 3;
    }
    startScroll(direction) {
      this.scrollDirection = direction;
      this.isScrolling = true;
      if (this.scrollAnimationId === null) {
        this.scrollSpeed = 0;
        this.runScrollAnimation();
      }
    }
    stopScroll() {
      this.isScrolling = false;
    }
    runScrollAnimation() {
      const scrollContainer = AmazonSelectors.getScrollContainer();
      if (!scrollContainer) {
        console.warn("[Kity][Amazon] Scroll container not found");
        this.scrollAnimationId = null;
        return;
      }
      if (this.isScrolling) {
        this.scrollSpeed = Math.min(this.scrollSpeed + this.scrollAcceleration, this.maxScrollSpeed);
      } else {
        this.scrollSpeed = Math.max(this.scrollSpeed - this.scrollDeceleration, 0);
      }
      if (this.scrollDirection === "up") {
        window.scrollBy(0, -this.scrollSpeed);
      } else if (this.scrollDirection === "down") {
        window.scrollBy(0, this.scrollSpeed);
      }
      if (this.scrollSpeed > 0) {
        this.scrollAnimationId = requestAnimationFrame(() => this.runScrollAnimation());
      } else {
        this.scrollAnimationId = null;
        this.scrollDirection = null;
      }
    }
  };

  // src/content/adapters/amazon/main.amazon.ts
  var AmazonAdapter = class {
    constructor() {
      this.id = "amazon";
      this.supports = {
        sidebar: false,
        mainPane: true
      };
      this.scrollManager = new ScrollManager5();
    }
    init() {
      console.log("%c[Kity] Amazon adapter initialized", "color: #FF9900; font-weight: bold;");
    }
    startScroll(direction) {
      this.scrollManager.startScroll(direction);
    }
    stopScroll() {
      this.scrollManager.stopScroll();
    }
    focusSidebar() {
      showToast("No sidebar navigation available");
    }
    focusMain() {
      const main = AmazonSelectors.getMain();
      if (main) {
        setFocusRing(main);
        window.setTimeout(() => main.classList.remove("kity-focus"), 400);
      } else {
        showToast("No main content found");
      }
    }
  };

  // src/content/adapters/adapter.generic.ts
  var GenericAdapter = class {
    constructor() {
      this.id = "generic";
      this.supports = {
        mainPane: true
      };
    }
    init() {
      console.log("[Kity] Generic adapter initialized");
    }
    focusMain() {
      const main = document.querySelector("main") || document.querySelector('[role="main"]') || document.body;
      const firstFocusable = main.querySelector("a, button, input, textarea, [tabindex]");
      if (firstFocusable) {
        setFocusRing(firstFocusable);
      } else {
        showToast("No focusable element found");
      }
    }
    navigateUp() {
      const focused = document.querySelector(".kity-focus");
      if (focused?.previousElementSibling) {
        setFocusRing(focused.previousElementSibling);
      }
    }
    navigateDown() {
      const focused = document.querySelector(".kity-focus");
      if (focused?.nextElementSibling) {
        setFocusRing(focused.nextElementSibling);
      }
    }
  };

  // src/themes/christmas/decorations.ts
  var animation_speed = 350;
  var ANIMATION_BUFFER = 50;
  function createChristmasDecorations(host = document) {
    let styleEl = null;
    let container = null;
    let unmountTimer = null;
    let pendingFrame = null;
    const ensureStyle = () => {
      if (styleEl) return;
      styleEl = host.createElement("style");
      styleEl.textContent = `
      .kity-xmas-decor {
        position: fixed;
        inset: 0;
        pointer-events: none;
        z-index: 2147483630;
        background: transparent !important;
      }

      .xmas-decor-top-left,
      .xmas-decor-bottom-right {
        position: absolute;
        display: block;
        user-select: none;
        mix-blend-mode: normal;
        background: transparent !important;
        filter: drop-shadow(0 10px 18px rgba(0, 0, 0, 0.18));
        will-change: transform, opacity;
        height: auto;
        max-width: none;
        opacity: 0;
      }

      .xmas-decor-top-left {
        top: -8px;
        left: -8px;
        width: clamp(90px, 11vw, 130px);
        transform: translate(-80%, -80%);
      }

      .xmas-decor-bottom-right {
        bottom: 0;
        right: 8px;
        width: clamp(70px, 9vw, 110px);
        transform: translateY(120%);
      }

      .kity-xmas-snow {
        position: fixed;
        inset: 0;
        pointer-events: none;
        overflow: hidden;
      }

      .kity-xmas-snow__flake {
        position: absolute;
        width: var(--flake-size, 6px);
        height: var(--flake-size, 6px);
        border-radius: 50%;
        background: var(--flake-color, rgba(166, 216, 255, 0.5));
        top: -10vh;
        animation: kity-xmas-snow-fall var(--flake-duration, 10s) linear infinite;
        will-change: transform, opacity;
        box-shadow: var(--flake-shadow, 0 0 8px rgba(166, 216, 255, 0.35));
      }

      @keyframes kity-xmas-snow-fall {
        0% {
          transform: translate3d(var(--flake-x, 0), -10vh, 0);
          opacity: 0.8;
        }
        60% {
          opacity: 0.9;
        }
        100% {
          transform: translate3d(calc(var(--flake-x, 0) + var(--flake-drift, 80px)), 110vh, 0);
          opacity: 0.2;
        }
      }

      @keyframes kity-xmas-top-left-in {
        from {
          transform: translate(-80%, -80%);
          opacity: 0;
        }
        to {
          transform: translate(0, 0);
          opacity: 1;
        }
      }

      @keyframes kity-xmas-bottom-right-in {
        from {
          transform: translateY(120%);
          opacity: 0;
        }
        to {
          transform: translateY(0);
          opacity: 1;
        }
      }

      @keyframes kity-xmas-top-left-out {
        from {
          transform: translate(0, 0);
          opacity: 1;
        }
        to {
          transform: translate(-80%, -80%);
          opacity: 0;
        }
      }

      @keyframes kity-xmas-bottom-right-out {
        from {
          transform: translateY(0);
          opacity: 1;
        }
        to {
          transform: translateY(120%);
          opacity: 0;
        }
      }

      .xmas-decor-top-left.is-in {
        animation: kity-xmas-top-left-in var(--kity-xmas-anim-speed, ${animation_speed}ms) ease-out forwards;
      }

      .xmas-decor-bottom-right.is-in {
        animation: kity-xmas-bottom-right-in var(--kity-xmas-anim-speed, ${animation_speed}ms) ease-out forwards;
      }

      .xmas-decor-top-left.is-out {
        animation: kity-xmas-top-left-out var(--kity-xmas-anim-speed, ${animation_speed}ms) ease-in forwards;
      }

      .xmas-decor-bottom-right.is-out {
        animation: kity-xmas-bottom-right-out var(--kity-xmas-anim-speed, ${animation_speed}ms) ease-in forwards;
      }

      @media (max-width: 900px) {
        .xmas-decor-top-left,
        .xmas-decor-bottom-right {
          opacity: 0.85;
        }
      }
    `;
      const head = host.head || host.documentElement || host.body;
      head?.appendChild(styleEl);
    };
    const mount = () => {
      ensureStyle();
      if (container) {
        return;
      }
      if (unmountTimer !== null) {
        clearTimeout(unmountTimer);
        unmountTimer = null;
      }
      if (pendingFrame !== null) {
        cancelAnimationFrame(pendingFrame);
        pendingFrame = null;
      }
      container = host.createElement("div");
      container.className = "kity-xmas-decor";
      container.style.setProperty("--kity-xmas-anim-speed", `${animation_speed}ms`);
      const placements = [
        { className: "xmas-decor-top-left", filename: "top-left-corner-1.png" },
        { className: "xmas-decor-bottom-right", filename: "snowman_bottom_right.png" }
      ];
      placements.forEach((item) => {
        const img = host.createElement("img");
        img.className = item.className;
        img.alt = "Christmas decoration";
        img.src = chrome.runtime.getURL(`themes/christmas/${item.filename}`);
        container?.appendChild(img);
      });
      const snowLayer = host.createElement("div");
      snowLayer.className = "kity-xmas-snow";
      const flakesPerSide = 25;
      const createFlakes = (side) => {
        for (let i = 0; i < flakesPerSide; i += 1) {
          const flake = host.createElement("div");
          flake.className = "kity-xmas-snow__flake";
          const baseX = side === "left" ? Math.random() * 35 : 65 + Math.random() * 35;
          const drift = (side === "left" ? 1 : -1) * (40 + Math.random() * 60);
          const size = 4 + Math.random() * 6;
          const duration = 8 + Math.random() * 6;
          const delay = Math.random() * 6;
          const cornerWeight = side === "left" ? Math.max(0, 1 - baseX / 35) : Math.max(0, (baseX - 65) / 35);
          const baseColor = { r: 166, g: 216, b: 255 };
          const darken = 22 * cornerWeight;
          const r = Math.max(120, baseColor.r - darken);
          const g = Math.max(160, baseColor.g - darken);
          const b = Math.max(200, baseColor.b - darken);
          const alpha = 0.4 + 0.25 * cornerWeight;
          flake.style.setProperty("--flake-x", `${baseX}vw`);
          flake.style.setProperty("--flake-drift", `${drift}px`);
          flake.style.setProperty("--flake-size", `${size}px`);
          flake.style.setProperty("--flake-duration", `${duration}s`);
          flake.style.setProperty("--flake-color", `rgba(${r}, ${g}, ${b}, ${alpha})`);
          flake.style.setProperty("--flake-shadow", `0 0 8px rgba(${r}, ${g}, ${b}, ${alpha * 0.7})`);
          flake.style.animationDelay = `${delay}s`;
          snowLayer.appendChild(flake);
        }
      };
      createFlakes("left");
      createFlakes("right");
      container.appendChild(snowLayer);
      (host.body || host.documentElement || host).appendChild(container);
      const animateIn = () => {
        if (!container) {
          return;
        }
        const images = Array.from(
          container.querySelectorAll(".xmas-decor-top-left, .xmas-decor-bottom-right")
        );
        images.forEach((img) => {
          img.classList.remove("is-out");
          void img.offsetWidth;
          img.classList.add("is-in");
        });
      };
      pendingFrame = requestAnimationFrame(animateIn);
    };
    const unmount = () => {
      if (!container) {
        return;
      }
      if (pendingFrame !== null) {
        cancelAnimationFrame(pendingFrame);
        pendingFrame = null;
      }
      const images = Array.from(
        container.querySelectorAll(".xmas-decor-top-left, .xmas-decor-bottom-right")
      );
      images.forEach((img) => {
        img.classList.remove("is-in");
        img.classList.add("is-out");
      });
      const teardown = () => {
        container?.remove();
        container = null;
        unmountTimer = null;
      };
      if (unmountTimer !== null) {
        clearTimeout(unmountTimer);
      }
      unmountTimer = window.setTimeout(teardown, animation_speed + ANIMATION_BUFFER);
    };
    return {
      mount,
      unmount,
      isMounted: () => !!container
    };
  }

  // src/content/singleGPTMode.ts
  var SINGLE_CHATGPT_MODE = true;
  var singleGPTModeEnabled = SINGLE_CHATGPT_MODE;
  function singleGPTMode(enabled) {
    singleGPTModeEnabled = enabled;
  }
  function shouldEnableForAlias(adapterAlias, desiredEnabled2) {
    if (!desiredEnabled2) {
      return false;
    }
    if (!singleGPTModeEnabled) {
      return true;
    }
    return adapterAlias === "gpt";
  }

  // src/content/index.ts
  var ENABLE_STORAGE_KEY = "kityEnabled";
  var THEME_DECOR_STORAGE_KEY = "kityThemeDecorEnabled";
  var currentAdapterAlias = detectAdapterAlias(new URL(window.location.href));
  var desiredEnabled = true;
  var currentAdapter = null;
  var isKityEnabled = null;
  var listenersAttached = false;
  var decorEnabled = false;
  var decorController = null;
  var SIDEBAR_NAV_REPEAT_MS = 70;
  var sidebarNavRepeatTimer = null;
  var sidebarNavDirection = null;
  var runtimeMessageHandler = (message) => {
    if (message.type === "KITY_SET_ENABLED") {
      setEnabledState(message.enabled);
      return;
    }
    if (message.type === "KITY_SET_THEME_ENABLED") {
      setDecorationsEnabled(message.enabled);
      return;
    }
    if (!isKityEnabled) {
      return;
    }
    if (message.type === "EXECUTE_COMMAND") {
      executeCommand(message.command);
    }
  };
  bootstrap();
  chrome.runtime.onMessage.addListener(runtimeMessageHandler);
  function singleGPTMode2(enabled) {
    singleGPTMode(enabled);
    setEnabledState(desiredEnabled);
  }
  function bootstrap() {
    chrome.storage.sync.get(
      [
        ENABLE_STORAGE_KEY,
        THEME_DECOR_STORAGE_KEY
      ],
      (items) => {
        const stored = items[ENABLE_STORAGE_KEY];
        const storedDecor = items[THEME_DECOR_STORAGE_KEY] ?? false;
        setEnabledState(stored === void 0 ? true : !!stored);
        setDecorationsEnabled(!!storedDecor);
      }
    );
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== "sync") {
        return;
      }
      if (ENABLE_STORAGE_KEY in changes) {
        const newValue = !!changes[ENABLE_STORAGE_KEY].newValue;
        setEnabledState(newValue);
      }
      if (THEME_DECOR_STORAGE_KEY in changes) {
        const newDecorValue = !!changes[THEME_DECOR_STORAGE_KEY].newValue;
        setDecorationsEnabled(newDecorValue);
      }
    });
  }
  function setEnabledState(enabled) {
    desiredEnabled = enabled;
    const shouldEnable = shouldEnableForAlias(currentAdapterAlias, desiredEnabled);
    const handlersMatchState = listenersAttached === shouldEnable;
    if (isKityEnabled === shouldEnable && handlersMatchState) {
      if (!shouldEnable) {
        decorController?.unmount();
      } else if (decorEnabled) {
        decorController?.mount();
      }
      return;
    }
    isKityEnabled = shouldEnable;
    if (shouldEnable) {
      ensureAdapter();
      attachGlobalHandlers();
      if (decorEnabled) {
        if (!decorController) {
          decorController = createChristmasDecorations(document);
        }
        decorController.mount();
      }
      console.info("[Kity] Enabled on this page");
    } else {
      detachGlobalHandlers();
      disposeAdapter();
      resetVisualState();
      decorController?.unmount();
      console.info("[Kity] Disabled on this page");
    }
  }
  function ensureAdapter() {
    if (currentAdapter) {
      return;
    }
    currentAdapter = createAdapter();
    currentAdapter.init();
  }
  function disposeAdapter() {
    if (!currentAdapter) {
      return;
    }
    currentAdapter.dispose?.();
    currentAdapter = null;
  }
  function attachGlobalHandlers() {
    if (listenersAttached) {
      return;
    }
    document.addEventListener("keydown", handleKeyDown);
    document.addEventListener("keyup", handleKeyUp);
    listenersAttached = true;
  }
  function detachGlobalHandlers() {
    if (!listenersAttached) {
      return;
    }
    document.removeEventListener("keydown", handleKeyDown);
    document.removeEventListener("keyup", handleKeyUp);
    listenersAttached = false;
  }
  function resetVisualState() {
    document.querySelectorAll(".kity-focus").forEach((element) => element.classList.remove("kity-focus"));
    document.querySelectorAll(".kity-selected").forEach((element) => element.classList.remove("kity-selected"));
  }
  function setDecorationsEnabled(enabled) {
    if (decorEnabled === enabled) {
      return;
    }
    decorEnabled = enabled;
    if (!isKityEnabled) {
      decorController?.unmount();
      return;
    }
    if (enabled) {
      if (!decorController) {
        decorController = createChristmasDecorations(document);
      }
      decorController.mount();
    } else {
      decorController?.unmount();
    }
  }
  function createAdapter() {
    const alias = currentAdapterAlias;
    if (alias === "gpt") {
      return new ChatGPTAdapter();
    }
    if (alias === "claude") {
      return new ClaudeAdapter();
    }
    if (alias === "gmail") {
      return new GmailAdapter();
    }
    if (alias === "google") {
      return new GoogleSearchAdapter();
    }
    if (alias === "gdrive") {
      return new GoogleDriveAdapter();
    }
    if (alias === "wpedia") {
      return new WikipediaAdapter();
    }
    if (alias === "amazon") {
      return new AmazonAdapter();
    }
    return new GenericAdapter();
  }
  function executeCommand(command) {
    if (!isKityEnabled) {
      return;
    }
    console.log("[Kity] Execute command:", command);
    if (!currentAdapter) {
      console.warn("[Kity] No adapter loaded");
      return;
    }
    const methodMap = {
      focusSidebar: "focusSidebar",
      focusMain: "focusMain",
      navigateUp: "navigateUp",
      navigateDown: "navigateDown",
      extendSelUp: "extendSelectionUp",
      extendSelDown: "extendSelectionDown",
      prevUser: "prevUser",
      nextUser: "nextUser",
      jumpToFirst: "jumpToFirst",
      jumpToLast: "jumpToLast",
      copySelected: "copySelected"
    };
    const method = methodMap[command];
    const fn = currentAdapter[method];
    if (fn && typeof fn === "function") {
      fn.call(currentAdapter);
    } else {
      console.warn("[Kity] Method not found or not a function:", method);
    }
  }
  function handleKeyDown(event) {
    if (!isKityEnabled) {
      return;
    }
    const target = event.target;
    const { altKey, shiftKey, ctrlKey, metaKey, key } = event;
    const isInInputField = target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable;
    if (isInInputField && !ctrlKey) {
      return;
    }
    if (ctrlKey && !shiftKey && !altKey && !metaKey && key === "ArrowLeft") {
      event.preventDefault();
      executeCommand("focusSidebar");
    } else if (ctrlKey && !shiftKey && !altKey && !metaKey && key === "ArrowRight") {
      event.preventDefault();
      executeCommand("focusMain");
    } else if (ctrlKey && !shiftKey && !altKey && !metaKey && key === "c") {
      event.preventDefault();
      executeCommand("copySelected");
    } else if (ctrlKey && !shiftKey && !altKey && !metaKey && key === "a") {
      event.preventDefault();
      const hasSelection = window.getSelection()?.toString().length;
      if (hasSelection) {
        executeCommand("extendSelUp");
      } else {
        executeCommand("jumpToFirst");
      }
    } else if (ctrlKey && !shiftKey && !altKey && !metaKey && key === "z") {
      event.preventDefault();
      const hasSelection = window.getSelection()?.toString().length;
      if (hasSelection) {
        executeCommand("extendSelDown");
      } else {
        executeCommand("jumpToLast");
      }
    } else if (ctrlKey && !shiftKey && !altKey && !metaKey && key === "ArrowUp") {
      event.preventDefault();
      const currentFocus = document.querySelector(".kity-focus");
      const sidebar = document.querySelector('nav[aria-label="Chat history"]') || document.querySelector("nav.flex-col.flex-1") || document.querySelector("nav");
      const isInSidebar = currentFocus && sidebar?.contains(currentFocus);
      if (isInSidebar) {
        if (!event.repeat) {
          startSidebarNavHold("up");
        }
      } else if (currentAdapter?.startScroll) {
        currentAdapter.startScroll("up");
      }
    } else if (ctrlKey && !shiftKey && !altKey && !metaKey && key === "ArrowDown") {
      event.preventDefault();
      const currentFocus = document.querySelector(".kity-focus");
      const sidebar = document.querySelector('nav[aria-label="Chat history"]') || document.querySelector("nav.flex-col.flex-1") || document.querySelector("nav");
      const isInSidebar = currentFocus && sidebar?.contains(currentFocus);
      if (isInSidebar) {
        if (!event.repeat) {
          startSidebarNavHold("down");
        }
      } else if (currentAdapter?.startScroll) {
        currentAdapter.startScroll("down");
      }
    } else if (ctrlKey && shiftKey && !altKey && !metaKey && key === "ArrowUp") {
      event.preventDefault();
      executeCommand("prevUser");
    } else if (ctrlKey && shiftKey && !altKey && !metaKey && key === "ArrowDown") {
      event.preventDefault();
      executeCommand("nextUser");
    } else if (ctrlKey && !shiftKey && !altKey && !metaKey && key === "Enter") {
      event.preventDefault();
      const focused = document.querySelector(".kity-focus");
      if (focused instanceof HTMLElement) {
        focused.click();
      }
    }
  }
  function handleKeyUp(event) {
    if (!isKityEnabled) {
      return;
    }
    const { key } = event;
    if (key === "ArrowUp" || key === "ArrowDown" || key === "Control" || key === "Alt") {
      currentAdapter?.stopScroll?.();
      stopSidebarNavHold();
    }
    if (currentAdapter && "resetCopyGlow" in currentAdapter && typeof currentAdapter.resetCopyGlow === "function") {
      currentAdapter.resetCopyGlow();
    }
  }
  function startSidebarNavHold(direction) {
    const command = direction === "up" ? "navigateUp" : "navigateDown";
    if (sidebarNavDirection && sidebarNavDirection !== direction) {
      stopSidebarNavHold();
    }
    executeCommand(command);
    if (sidebarNavRepeatTimer !== null) {
      return;
    }
    sidebarNavDirection = direction;
    sidebarNavRepeatTimer = window.setInterval(() => executeCommand(command), SIDEBAR_NAV_REPEAT_MS);
  }
  function stopSidebarNavHold() {
    if (sidebarNavRepeatTimer !== null) {
      window.clearInterval(sidebarNavRepeatTimer);
      sidebarNavRepeatTimer = null;
    }
    sidebarNavDirection = null;
  }
})();
