"use strict";
(() => {
  // src/shared/license.ts
  var LICENSE_STORAGE_KEYS = {
    plan: "kityPlan",
    email: "kityUserEmail",
    forceLocalFree: "kityForceLocalFree",
    lastSyncedAt: "kityLicenseLastSyncedAt",
    token: "kityAuthToken"
  };
  var defaultState = {
    plan: "pro",
    email: null,
    forceLocalFree: false,
    lastSyncedAt: null,
    token: null
  };
  var LicenseService = class {
    constructor() {
      this.state = { ...defaultState };
      this.listeners = /* @__PURE__ */ new Set();
      this.initialized = false;
      this.handleStorageChange = this.handleStorageChange.bind(this);
    }
    isPaid() {
      return true;
    }
    hasAccess() {
      return hasActiveAccess(this.state);
    }
    getEmail() {
      return this.state.email;
    }
    getState() {
      return { ...this.state };
    }
    onChange(listener) {
      this.listeners.add(listener);
      return () => this.listeners.delete(listener);
    }
    async init() {
      await this.loadFromStorage();
      await this.refreshFromBackend();
      if (!this.initialized) {
        chrome.storage.onChanged.addListener(this.handleStorageChange);
        this.initialized = true;
      }
      return this.getState();
    }
    async refreshFromBackend() {
      return this.ensureProAccess();
    }
    async signIn(options) {
      await this.persistState({
        plan: "pro",
        email: options?.email ?? this.state.email,
        forceLocalFree: false,
        lastSyncedAt: (/* @__PURE__ */ new Date()).toISOString(),
        token: options?.token ?? this.state.token ?? "local-pro"
      });
      return this.getState();
    }
    async signOutLocally() {
      await this.persistState({
        ...defaultState,
        forceLocalFree: true,
        lastSyncedAt: (/* @__PURE__ */ new Date()).toISOString()
      });
      return this.getState();
    }
    async persistState(partial) {
      const nextState = {
        ...this.state,
        ...partial
      };
      await new Promise((resolve) => {
        chrome.storage.sync.set(
          {
            [LICENSE_STORAGE_KEYS.plan]: nextState.plan,
            [LICENSE_STORAGE_KEYS.email]: nextState.email,
            [LICENSE_STORAGE_KEYS.forceLocalFree]: nextState.forceLocalFree,
            [LICENSE_STORAGE_KEYS.lastSyncedAt]: nextState.lastSyncedAt,
            [LICENSE_STORAGE_KEYS.token]: nextState.token
          },
          () => resolve()
        );
      });
      this.state = nextState;
      this.notify();
    }
    async loadFromStorage() {
      const items = await new Promise((resolve) => {
        chrome.storage.sync.get(
          Object.values(LICENSE_STORAGE_KEYS),
          (result) => resolve(result)
        );
      });
      this.state = {
        plan: "pro",
        email: items[LICENSE_STORAGE_KEYS.email] ?? null,
        forceLocalFree: !!items[LICENSE_STORAGE_KEYS.forceLocalFree],
        lastSyncedAt: items[LICENSE_STORAGE_KEYS.lastSyncedAt] ?? null,
        token: items[LICENSE_STORAGE_KEYS.token] ?? null
      };
      await this.ensureProAccess();
      this.notify();
    }
    handleStorageChange(changes, areaName) {
      if (areaName !== "sync") return;
      const relevantKeys = Object.values(LICENSE_STORAGE_KEYS);
      const hasChange = relevantKeys.some((key) => key in changes);
      if (!hasChange) {
        return;
      }
      const newState = { ...this.state };
      if (LICENSE_STORAGE_KEYS.plan in changes) {
        newState.plan = changes[LICENSE_STORAGE_KEYS.plan].newValue ?? "pro";
      }
      if (LICENSE_STORAGE_KEYS.email in changes) {
        newState.email = changes[LICENSE_STORAGE_KEYS.email].newValue ?? null;
      }
      if (LICENSE_STORAGE_KEYS.forceLocalFree in changes) {
        newState.forceLocalFree = !!changes[LICENSE_STORAGE_KEYS.forceLocalFree].newValue;
      }
      if (LICENSE_STORAGE_KEYS.lastSyncedAt in changes) {
        newState.lastSyncedAt = changes[LICENSE_STORAGE_KEYS.lastSyncedAt].newValue ?? null;
      }
      if (LICENSE_STORAGE_KEYS.token in changes) {
        newState.token = changes[LICENSE_STORAGE_KEYS.token].newValue ?? null;
      }
      this.state = newState;
      this.notify();
    }
    notify() {
      this.listeners.forEach((listener) => listener(this.getState()));
    }
    async ensureProAccess() {
      if (this.state.plan !== "pro" || this.state.forceLocalFree) {
        await this.persistState({
          plan: "pro",
          forceLocalFree: false,
          lastSyncedAt: (/* @__PURE__ */ new Date()).toISOString()
        });
      }
      return this.getState();
    }
  };
  function hasActiveAccess(state) {
    return !state.forceLocalFree;
  }

  // src/common/tabs.ts
  var CHAT_GPT_URL_PATTERNS = [
    "https://chat.openai.com/*",
    "https://chatgpt.com/*"
  ];
  function queryAllChatGptTabs(callback) {
    chrome.tabs.query({ url: CHAT_GPT_URL_PATTERNS }, callback);
  }

  // src/popup/background.ts
  var ACTIVE_ICON = {
    16: "icons/Icon16px.png",
    32: "icons/Icon32px.png",
    48: "icons/Icon48px.png",
    128: "icons/Icon128px.png"
  };
  var INACTIVE_ICON = {
    16: "icons/Icon_grey16px.png",
    32: "icons/Icon_grey32px.png",
    48: "icons/Icon_grey48px.png",
    128: "icons/Icon_grey128px.png"
  };
  var STORAGE_KEYS = {
    enabled: "kityEnabled"
  };
  var LOCAL_STORAGE_KEYS = {
    enabled: "kityEnabledLocal"
  };
  var DOCS_URL = "https://kity.software/";
  var licenseService = new LicenseService();
  var cachedEnabled = null;
  var runtimeFunctionalEnabled = false;
  chrome.action.setIcon({ path: INACTIVE_ICON });
  void loadLocalEnabled();
  void initializeLicense();
  refreshLicenseAfterDelay(1e3);
  chrome.runtime.onInstalled.addListener(() => {
    primeEnabledState({ setDefaultIfMissing: true });
  });
  chrome.runtime.onStartup?.addListener(() => {
    primeEnabledState({ setDefaultIfMissing: false });
    refreshLicenseAfterDelay(500);
  });
  chrome.runtime.onMessage.addListener(
    (message, _sender, sendResponse) => {
      let willRespondAsync = false;
      switch (message.type) {
        case "KITY_OPEN_DOCS":
          handleOpenDocs();
          sendResponse({ ok: true });
          break;
        case "KITY_GET_STATUS":
          willRespondAsync = true;
          void handleGetStatus(sendResponse);
          break;
        case "KITY_SIGN_OUT":
          willRespondAsync = true;
          void handleSignOut(sendResponse);
          break;
        case "KITY_UPDATE_ICON":
          cachedEnabled = message.enabled;
          updateEffectiveState();
          sendResponse?.({ ok: true });
          break;
        default:
          break;
      }
      return willRespondAsync;
    }
  );
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "sync") return;
    let shouldRecompute = false;
    if (STORAGE_KEYS.enabled in changes) {
      cachedEnabled = !!changes[STORAGE_KEYS.enabled].newValue;
      shouldRecompute = true;
    }
    if (LICENSE_STORAGE_KEYS.plan in changes || LICENSE_STORAGE_KEYS.forceLocalFree in changes) {
      shouldRecompute = true;
    }
    if (shouldRecompute) {
      updateEffectiveState();
    }
  });
  async function initializeLicense() {
    await licenseService.init();
    updateEffectiveState();
  }
  async function handleGetStatus(sendResponse) {
    try {
      await licenseService.refreshFromBackend();
    } catch (error) {
      console.warn("Failed to refresh license", error);
    }
    const state = licenseService.getState();
    sendResponse({
      enabled: cachedEnabled ?? true,
      hasToken: !!state.token,
      userEmail: state.forceLocalFree ? null : state.email,
      plan: state.plan,
      forceLocalFree: state.forceLocalFree
    });
  }
  async function handleSignOut(sendResponse) {
    try {
      await licenseService.signOutLocally();
      updateEffectiveState();
      sendResponse({ ok: true });
    } catch (error) {
      console.warn("Error signing out:", error);
      sendResponse({ ok: false });
    }
  }
  function handleOpenDocs() {
    chrome.tabs.create({ url: DOCS_URL }, () => {
      if (chrome.runtime.lastError) {
        console.warn("Error opening docs tab:", chrome.runtime.lastError.message);
      }
    });
  }
  function broadcastEnabledState(enabled) {
    queryAllChatGptTabs((tabs) => {
      tabs.forEach((tab) => {
        if (!tab.id) {
          return;
        }
        chrome.tabs.sendMessage(
          tab.id,
          { type: "KITY_SET_ENABLED", enabled },
          () => {
            if (chrome.runtime.lastError) {
            }
          }
        );
      });
    });
  }
  function updateActionIcon(enabled) {
    chrome.action.setIcon({
      path: enabled ? ACTIVE_ICON : INACTIVE_ICON
    });
  }
  function primeEnabledState(options) {
    chrome.storage.sync.get([STORAGE_KEYS.enabled], (items) => {
      const stored = items[STORAGE_KEYS.enabled];
      const hasStored = stored !== void 0;
      if (hasStored) {
        cachedEnabled = !!stored;
      } else if (options?.setDefaultIfMissing) {
        cachedEnabled = true;
        chrome.storage.sync.set({ [STORAGE_KEYS.enabled]: true }, () => {
          updateEffectiveState();
        });
      }
      updateEffectiveState();
    });
  }
  function computeEffectiveEnabled() {
    const licenseState = licenseService.getState();
    const hasAccess = hasActiveAccess({
      forceLocalFree: licenseState.forceLocalFree
    });
    return !!cachedEnabled && hasAccess;
  }
  function updateEffectiveState() {
    if (cachedEnabled === null) {
      return;
    }
    const functionalEnabled = computeEffectiveEnabled();
    updateActionIcon(cachedEnabled);
    chrome.storage.local.set({ [LOCAL_STORAGE_KEYS.enabled]: cachedEnabled });
    if (runtimeFunctionalEnabled === functionalEnabled) {
      return;
    }
    runtimeFunctionalEnabled = functionalEnabled;
    broadcastEnabledState(functionalEnabled);
  }
  function loadLocalEnabled() {
    return new Promise((resolve) => {
      chrome.storage.local.get([LOCAL_STORAGE_KEYS.enabled], (items) => {
        const storedLocal = items[LOCAL_STORAGE_KEYS.enabled];
        if (storedLocal !== void 0 && cachedEnabled === null) {
          cachedEnabled = !!storedLocal;
          updateEffectiveState();
        }
        resolve();
      });
    });
  }
  function refreshLicenseAfterDelay(delayMs) {
    setTimeout(() => {
      void licenseService.refreshFromBackend().then(() => updateEffectiveState());
    }, delayMs);
  }
})();
